/* =====================================================================
   AnimatedBackgrounds.me API  (Cloudflare Worker + KV, free plan)
   ---------------------------------------------------------------------
   Collection requests ("Add tag" in the preview) and new-background
   submissions are stored in KV. Nothing changes on the site until the
   owner approves a request on /requests/. Approving commits the change
   to data/backgrounds.json on GitHub; the GitHub Action then rebuilds.

   Routes
     POST /api/requests                    public: create a request
     POST /api/login                       admin : check the password
     GET  /api/requests                    admin : pending + decided
     POST /api/requests/:key/approve       admin : commit + mark approved
     POST /api/requests/:key/reject        admin : mark rejected
   Admin routes need  Authorization: Bearer <ADMIN_PASSWORD>.

   Secrets (wrangler secret put …):
     ADMIN_PASSWORD – unique secret used to protect /requests/; configure it outside source control
     GITHUB_TOKEN   – fine-grained PAT, "Contents: read & write" on the repo
   Vars (wrangler.toml): GITHUB_REPO, GITHUB_BRANCH, SITE_URL, ALLOWED_ORIGINS
   KV binding: REQUESTS
   ===================================================================== */

const DATA_FILE = 'data/backgrounds.json';
const ID_RE = /^[A-Za-z0-9]{4,12}$/;
const USER_RE = /^[A-Za-z0-9_-]{1,40}$/;
const SLUG_RE = /^[a-z0-9-]{1,40}$/;
const DAY = 86400;

/* ---------------- helpers ---------------- */
function corsHeaders(env, origin) {
  const allowed = String(env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
  const ok = allowed.includes(origin) || /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin);
  return {
    'access-control-allow-origin': ok ? origin : (allowed[0] || '*'),
    'access-control-allow-methods': 'GET, POST, OPTIONS',
    'access-control-allow-headers': 'content-type, authorization',
    'access-control-max-age': '86400',
    vary: 'origin'
  };
}
const json = (obj, status, cors) => new Response(JSON.stringify(obj), { status, headers: { 'content-type': 'application/json', 'cache-control': 'no-store', ...cors } });
function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
const clean = (s, max) => String(s ?? '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, max);
const ipOf = req => req.headers.get('cf-connecting-ip') || 'unknown';
const b64encode = str => { const bytes = new TextEncoder().encode(str); let bin = ''; for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000)); return btoa(bin); };
const b64decode = b64 => new TextDecoder().decode(Uint8Array.from(atob(b64.replace(/\n/g, '')), c => c.charCodeAt(0)));

async function bump(env, key, ttl) {
  const n = (+(await env.REQUESTS.get(key)) || 0) + 1;
  await env.REQUESTS.put(key, String(n), { expirationTtl: ttl });
  return n;
}

/* ---------------- GitHub ---------------- */
async function gh(env, path, init = {}) {
  return fetch(`https://api.github.com/repos/${env.GITHUB_REPO}/${path}`, {
    ...init,
    headers: {
      authorization: `Bearer ${env.GITHUB_TOKEN}`, accept: 'application/vnd.github+json',
      'user-agent': 'animatedbackgrounds-api', 'x-github-api-version': '2022-11-28', ...(init.headers || {})
    }
  });
}
async function readLibrary(env) {
  const branch = env.GITHUB_BRANCH || 'main';
  const r = await gh(env, `contents/${DATA_FILE}?ref=${branch}`);
  if (!r.ok) throw new Error(`GitHub read ${r.status}`);
  const j = await r.json();
  return { sha: j.sha, data: JSON.parse(b64decode(j.content)) };
}
async function writeLibrary(env, data, sha, message) {
  const r = await gh(env, `contents/${DATA_FILE}`, {
    method: 'PUT',
    body: JSON.stringify({ message, content: b64encode(JSON.stringify(data)), sha, branch: env.GITHUB_BRANCH || 'main' })
  });
  if (!r.ok) { const e = new Error(`GitHub write ${r.status}: ${(await r.text()).slice(0, 200)}`); e.status = r.status; throw e; }
}
// public library (for validating requests) — cached at the edge for 5 minutes
async function publicLibrary(env) {
  const r = await fetch(`${env.SITE_URL}/data/backgrounds.json`, { cf: { cacheTtl: 300, cacheEverything: true } });
  if (!r.ok) throw new Error('library unavailable');
  return r.json();
}

function applyRequest(data, rq) {
  const cat = data.categories.find(c => c.slug === rq.collection);
  if (!cat) return 'Collection no longer exists';
  if (rq.type === 'new') {
    const ex = data.backgrounds.find(b => b.id === rq.id);
    if (ex) { ex.tags = [...new Set([...(ex.tags || []), rq.collection])]; return null; }
    const o = { id: rq.id, user: rq.user || 'username' };
    if (rq.title) o.title = rq.title;
    if (rq.author) o.author = rq.author;
    o.tags = [rq.collection];
    data.backgrounds.unshift(o);
    return null;
  }
  const b = data.backgrounds.find(x => x.id === rq.id);
  if (!b) return 'Background not found';
  b.tags = [...new Set([...(b.tags || []), rq.collection])];
  return null;
}

/* ---------------- handlers ---------------- */
async function createRequest(req, env, cors) {
  const ip = ipOf(req);
  if (await bump(env, `rl:${ip}`, 3600) > 20) return json({ error: 'Too many requests. Please try again later.' }, 429, cors);
  let body; try { body = await req.json(); } catch (e) { return json({ error: 'Invalid JSON' }, 400, cors); }
  if (body.website) return json({ ok: true }, 200, cors); // honeypot

  const type = body.type === 'new' ? 'new' : 'tag';
  const id = clean(body.id, 12), collection = clean(body.collection, 40), user = clean(body.user, 40);
  if (!ID_RE.test(id)) return json({ error: 'Invalid background ID' }, 400, cors);
  if (!SLUG_RE.test(collection)) return json({ error: 'Choose a collection' }, 400, cors);
  if (type === 'new' && user && !USER_RE.test(user)) return json({ error: 'Invalid CodePen user' }, 400, cors);

  const lib = await publicLibrary(env);
  const cat = lib.categories.find(c => c.slug === collection);
  if (!cat) return json({ error: 'Unknown collection' }, 400, cors);
  const bg = lib.backgrounds.find(b => b.id === id);
  if (type === 'tag' && !bg) return json({ error: 'Unknown background' }, 400, cors);
  if (bg && (bg.tags || []).includes(collection)) return json({ ok: true, already: true, message: `Already in ${cat.name}` }, 200, cors);

  const dupKey = `dup:${type}:${id}:${collection}`;
  if (await env.REQUESTS.get(dupKey)) return json({ ok: true, duplicate: true }, 200, cors);

  const key = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
  const record = {
    key, type, id, collection, collectionName: cat.name,
    user: type === 'new' ? (user || 'username') : bg.user,
    title: type === 'new' ? clean(body.title, 120) : (bg.title || ''),
    from: clean(body.name, 60), note: clean(body.note, 280),
    created: new Date().toISOString(), status: 'pending'
  };
  await env.REQUESTS.put(`req:${key}`, JSON.stringify(record));
  await env.REQUESTS.put(dupKey, key, { expirationTtl: 30 * DAY });
  return json({ ok: true, key }, 201, cors);
}

async function listRequests(env, cors) {
  const load = async prefix => {
    const out = []; let cursor;
    do {
      const page = await env.REQUESTS.list({ prefix, cursor, limit: 1000 });
      const vals = await Promise.all(page.keys.map(k => env.REQUESTS.get(k.name, 'json')));
      out.push(...vals.filter(Boolean));
      cursor = page.list_complete ? null : page.cursor;
    } while (cursor && out.length < 2000);
    return out;
  };
  const [pending, decided] = await Promise.all([load('req:'), load('done:')]);
  pending.sort((a, b) => a.created.localeCompare(b.created));
  decided.sort((a, b) => (b.decided || '').localeCompare(a.decided || ''));
  return json({ pending, decided: decided.slice(0, 100) }, 200, cors);
}

async function decide(env, key, action, cors) {
  const rq = await env.REQUESTS.get(`req:${key}`, 'json');
  if (!rq) return json({ error: 'Request not found (already decided?)' }, 404, cors);

  if (action === 'approve') {
    if (!env.GITHUB_TOKEN || !env.GITHUB_REPO) return json({ error: 'Worker is missing GITHUB_TOKEN / GITHUB_REPO' }, 500, cors);
    for (let attempt = 0; attempt < 3; attempt++) {
      const { sha, data } = await readLibrary(env);
      const err = applyRequest(data, rq);
      if (err) return json({ error: err }, 409, cors);
      try {
        const what = rq.type === 'new' ? `Add background ${rq.id}` : `Add ${rq.id}`;
        await writeLibrary(env, data, sha, `${what} to ${rq.collectionName} (approved request ${rq.key})`);
        break;
      } catch (e) { if (e.status !== 409 || attempt === 2) throw e; } // sha changed — retry
    }
  }
  const done = { ...rq, status: action === 'approve' ? 'approved' : 'rejected', decided: new Date().toISOString() };
  await env.REQUESTS.put(`done:${key}`, JSON.stringify(done), { expirationTtl: 90 * DAY });
  await env.REQUESTS.delete(`req:${key}`);
  return json({ ok: true, request: done }, 200, cors);
}

async function isAdmin(req, env) {
  const ip = ipOf(req);
  const fails = +(await env.REQUESTS.get(`fail:${ip}`)) || 0;
  if (fails >= 10) return 'locked';
  const auth = req.headers.get('authorization') || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
  if (env.ADMIN_PASSWORD && safeEqual(token, env.ADMIN_PASSWORD)) return 'ok';
  await bump(env, `fail:${ip}`, 900);
  return 'denied';
}


async function mutateBackground(req, env, action, cors) {
  if (!env.GITHUB_TOKEN || !env.GITHUB_REPO) return json({ error: 'Worker is missing GITHUB_TOKEN / GITHUB_REPO' }, 500, cors);
  let body; try { body = await req.json(); } catch (e) { return json({ error: 'Invalid JSON' }, 400, cors); }
  const id = clean(body.id, 16);
  if (!ID_RE.test(id)) return json({ error: 'Invalid background ID' }, 400, cors);

  for (let attempt = 0; attempt < 3; attempt++) {
    const { sha, data } = await readLibrary(env);
    let msg = '';
    if (action === 'remove') {
      const b = data.backgrounds.find(x => x.id === id);
      if (!b) return json({ error: 'Background not found' }, 404, cors);
      b.hidden = true;
      msg = `Remove background ${id} via /requests/`;
    } else if (action === 'restore') {
      const b = data.backgrounds.find(x => x.id === id);
      if (!b) return json({ error: 'Background not found' }, 404, cors);
      delete b.hidden;
      msg = `Restore background ${id} via /requests/`;
    } else if (action === 'add') {
      const user = clean(body.user, 40) || 'username';
      const title = clean(body.title, 120);
      const author = clean(body.author, 80);
      const validSlugs = new Set((data.categories || []).map(c => c.slug));
      const tags = Array.isArray(body.tags) ? body.tags.map(t => clean(t, 40)).filter(t => validSlugs.has(t)) : [];
      const ex = data.backgrounds.find(x => x.id === id);
      if (ex) {
        delete ex.hidden;
        if (title) ex.title = title;
        if (author) ex.author = author;
        if (tags.length) ex.tags = [...new Set([...(ex.tags || []), ...tags])];
      } else {
        const entry = { id, user, tags };
        if (title) entry.title = title;
        if (author) entry.author = author;
        data.backgrounds.unshift(entry);
      }
      msg = `Add background ${id} via /requests/`;
    }
    try {
      await writeLibrary(env, data, sha, msg);
      return json({ ok: true, id, action }, 200, cors);
    } catch (e) { if (e.status !== 409 || attempt === 2) throw e; }
  }
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const cors = corsHeaders(env, req.headers.get('origin') || '');
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });
    if (!env.REQUESTS) return json({ error: 'KV binding REQUESTS is missing' }, 500, cors);
    const p = url.pathname.replace(/\/+$/, '');

    try {
      if (req.method === 'GET' && (p === '' || p === '/api')) return json({ ok: true, service: 'animatedbackgrounds-api' }, 200, cors);
      if (req.method === 'POST' && p === '/api/requests') return await createRequest(req, env, cors);

      if (p === '/api/login' || p.startsWith('/api/requests') || p.startsWith('/api/backgrounds')) {
        const a = await isAdmin(req, env);
        if (a === 'locked') return json({ error: 'Too many wrong passwords. Try again in 15 minutes.' }, 429, cors);
        if (a !== 'ok') return json({ error: 'Wrong password' }, 401, cors);
        if (req.method === 'POST' && p === '/api/login') return json({ ok: true }, 200, cors);
        if (req.method === 'GET' && p === '/api/requests') return await listRequests(env, cors);
        const m = p.match(/^\/api\/requests\/([a-z0-9]+)\/(approve|reject)$/);
        if (req.method === 'POST' && m) return await decide(env, m[1], m[2], cors);
        const bm = p.match(/^\/api\/backgrounds\/(add|remove|restore)$/);
        if (req.method === 'POST' && bm) return await mutateBackground(req, env, bm[1], cors);
      }
      return json({ error: 'Not found' }, 404, cors);
    } catch (e) {
      return json({ error: String(e.message || e).slice(0, 300) }, 500, cors);
    }
  }
};
