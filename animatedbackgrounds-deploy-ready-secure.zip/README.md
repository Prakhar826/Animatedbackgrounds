# Animated Backgrounds (v3)

Static site for **animatedbackgrounds.me** — 657 hand-picked CSS / Canvas / WebGL
animated backgrounds. Zero-dependency Node ESM builder → `dist/`, deployed to
GitHub Pages by `.github/workflows/deploy.yml`.

## What changed in v3

| # | Request | Where |
|---|---------|-------|
| 1 | **No more "Screenshot missing"** | All 657 screenshots are hosted locally in `assets/shots/<id>.jpg` (640×360 JPEG). `data/meta.json` lists the ids we have, so the app never requests a missing file; if one is ever absent it renders a tinted gradient tile (`.shot-fallback`) instead of a broken image. CodePen-shot 404s are gone entirely. |
| 2 | **Email subscribe form** | `newsletterHTML()` in `assets/js/app.js` + `.subscribe` CSS. Posts `multipart/form-data` to `https://blog.animatedbackgrounds.me/_ob/subscribe` through a hidden iframe (same endpoint the blog uses — no CORS needed). Present on the home page and in `/guide/`. |
| 3 | **Unique collection images + popular picks** | `scripts/build.mjs` computes `picks` per collection: top-scored backgrounds, and an id already used by another collection is skipped → the "All Collections" collage never repeats a picture. Written to `data/meta.json` → `picks`. |
| 4 | **"Add tag" → owner approval** | `#modal-tag` button + tag panel (`openTagPanel`). Sends `POST {apiBase}/api/requests` (Cloudflare Worker `worker/api.js`, KV). Requests land on **`/requests/`** (noindex; locked until an administrator configures a new password), each with **Approve** / **Reject**. Approving commits the tag into `data/backgrounds.json` via the GitHub API → the Action rebuilds → the tag appears. |
| 5 | **Blog on its own subdomain** | `templates/shell.html` redirects `/blog*` → `https://blog.animatedbackgrounds.me/` before paint; `scripts/build.mjs` emits `blog/index.html`, `blog.html`, `blog/rss.xml` → redirects. No blog posts or blog code remain in this repo. |
| 6 | **Floating Carbon ad** | `.carbon-float` (bottom-right, glass panel, orange accent bar) + official snippet injected by `initCarbon()` into `#carbon-slot` (`serve=CESI523J`, `placement=animatedbackgroundsme`, `format=cover`). Minimize / dismiss, remembered in localStorage, auto-hides if blocked. |
| 7 | **Hero = CSS infinite photo carousel** | `heroHTML()` + `.hero`, `.hero-reel`, `.hero-row`, `@keyframes heroScroll` — rebuilt from *CSS infinite photo carousel* (codepen.io/minimamente/pen/WNrZVvP): 3 rotated rows of real screenshots scrolling at different speeds, `translateX(-50%)` for a seamless loop, CSS-var sizing for responsiveness, dark radial scrim for readable text, disabled under `prefers-reduced-motion`. |
| 8 | **Blog cards from RSS** | Build step fetches `blog.animatedbackgrounds.me/rss.xml` (falls back to scraping the blog index), writes `dist/data/blog.json`; the SPA renders those cards linking straight to the blog. |
| 8b | **Guide** | `/guide/` — 12 steps (pick, layer, iframe, CSS-only, canvas, React, Vue, builders, apps, readability, performance, license) + FAQ, HowTo/FAQPage/BreadcrumbList JSON-LD, copy-code buttons. |
| 9 | **Theme matches the logo** | Rewritten design tokens: warm paper `#faf9f7`, orange `#f26b1d`, i.e. `--primary:#f26b1d`, flat cards, 1px borders, 12–16px radii, Inter. Minimal like the blog, still with cards/previews. Dark theme `#0e0e0e`. |

## Layout

```
assets/css/{site,app}.css      design system + components (hero, subscribe, tag, admin, carbon)
assets/js/app.js               SPA (hash-free router, hero, cards, tag requests, newsletter, carbon ad)
assets/js/monetize*.js         optional idle-compute SDK (unchanged)
assets/shots/*.jpg             545 hosted screenshots (the 404 fix)
data/backgrounds.json          657 backgrounds, 12 collections
data/stats.json                view/like counters
data/meta.json                 generated: shots, picks, hero  (do not edit by hand)
scripts/build.mjs              the whole static build
scripts/guide.mjs              /guide/ content + structured data
scripts/fetch-stats.mjs        counter refresh (cron)
templates/shell.html           app shell (%%TOKENS%%)
templates/sw.js                service worker
worker/                        Cloudflare Worker + KV for /requests/ approval flow
```

## Commands

```bash
node scripts/build.mjs      # -> dist/
node scripts/fetch-stats.mjs
# preview
npx serve dist -l 3000
```

Deploying the request API (once):

```bash
cd worker
npx wrangler kv namespace create REQUESTS     # paste the id into wrangler.toml
npx wrangler secret put ADMIN_PASSWORD        # choose a strong, unique password
npx wrangler secret put GITHUB_TOKEN          # fine-grained PAT, Contents: read & write
npx wrangler deploy
```
Then set `"apiBase": "https://<worker>.workers.dev"` in `site.config.json` and rebuild.
Until then the "Add tag" form gracefully falls back to an email link.

## Owner queue
`/requests/` — owner-only queue (noindex, not in the sitemap). It is locked by default. To enable it, set a strong unique `ADMIN_PASSWORD` Worker secret and put the SHA-256 hash of the same password in `site.config.json` as `adminHash`. Do not store the plaintext password in the repository.

## Credit
Every background belongs to its CodePen author — check the pen's license before use.
