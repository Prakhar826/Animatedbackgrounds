import json, re, html
d = json.load(open('/tmp/lists.json'))
titles = json.load(open('/tmp/titles.json'))
titles = {k: v for k, v in titles.items() if 't' in v}
curmap = {'wave.js':'waves','Bubble.js':'bubbles','fluid.js':'fluid','3d.html':'3d','Noise.html':'noise',
          'heart.html':'hearts','pattern.html':'patterns','Tunnel.html':'tunnel'}
order, users, tags, featured = [], {}, {}, set()
def add(pid, user=None):
    if pid not in users: order.append(pid); users[pid] = 'username'; tags[pid] = []
    if user and user not in ('username',): users[pid] = user
for x in d['main']: add(x.split('/')[-1])
for f, lst in d['sets'].items():
    cat = curmap.get(f)
    for x in lst:
        p = x.split('/'); add(p[-1], p[0] if p[0] != 'pleasedonotdisturb' or True else None)
        if cat:
            featured.add(p[-1])
            if cat not in tags[p[-1]]: tags[p[-1]].append(cat)
RULES = [
 ('waves',      r'\bwaves?\b|ripple|sine|ocean|\bsea\b|pond|tide'),
 ('bubbles',    r'bubble|bokeh|blob|beads|orbs?\b'),
 ('hearts',     r'heart|\blove\b|valentine'),
 ('particles',  r'particle|starfield|snow|glitter|\bdots?\b|dodgers|swarm|confetti|firefl|gravity|explosion|flow field'),
 ('space',      r'\bstars?\b|starfield|galaxy|space|cosmic|\bsky\b|night'),
 ('gradient',   r'gradient|colou?r|chameleon|blend|\bhue|rainbow|unicorn|shader'),
 ('patterns',   r'pattern|kaleidoscope|\bhex|tiles?\b|grid|geometr|squares|circles|triangles|mirror|\blines\b|stripes|blinds|seahorse|contortion|illusion'),
 ('3d',         r'\b3d\b|cube|three|webgl|synthwave|tron'),
 ('tunnel',     r'tunnel|hyperspace|tron|travel'),
 ('fluid',      r'fluid|liquid|\bflow|morph|\bink\b|turbulence|smoke|cinamon|mitosys'),
 ('noise',      r'noise|perlin|simplex|glitch|static'),
 ('interactive',r'mouse|hover|cursor|interactive|click'),
]
out = []
for i, pid in enumerate(order):
    t = titles.get(pid, {})
    title = html.unescape(t.get('t', '')).strip().strip('"').strip()
    if title == pid: title = ''
    if t.get('u'): users[pid] = t['u']
    tg = list(tags[pid])
    if title:
        for cat, rx in RULES:
            if re.search(rx, title, re.I) and cat not in tg: tg.append(cat)
    item = {'id': pid, 'user': users[pid]}
    if title: item['title'] = title
    if t.get('a'): item['author'] = html.unescape(t['a'])
    item['tags'] = tg
    if pid in featured: item['featured'] = True
    out.append(item)
cats = [
 {'slug':'waves','name':'Wave Animations','icons':['fa-water','fa-wave-square'],'tint':['#dff3ff','#eef0ff'],'desc':'Smooth sine waves, ocean motion and ripple effects.'},
 {'slug':'bubbles','name':'Bubbles & Blobs','icons':['fa-circle','fa-circle-dot'],'tint':['#e8f7ff','#f3eaff'],'desc':'Floating bubbles, bokeh lights and morphing blobs.'},
 {'slug':'hearts','name':'Hearts & Love','icons':['fa-heart','fa-heart-pulse'],'tint':['#ffe9f1','#fff1ea'],'desc':'Romantic floating hearts for Valentine and love themes.'},
 {'slug':'particles','name':'Particles','icons':['fa-wand-sparkles','fa-atom'],'tint':['#fff6dd','#ffeef3'],'desc':'Particle systems, snow, glitter, dots and flow fields.'},
 {'slug':'space','name':'Space & Stars','icons':['fa-star','fa-rocket'],'tint':['#e9ecff','#f5e9ff'],'desc':'Starfields, galaxies and night skies.'},
 {'slug':'gradient','name':'Gradients','icons':['fa-palette','fa-droplet'],'tint':['#ffeefa','#e9f6ff'],'desc':'Animated colour gradients and shader colour flows.'},
 {'slug':'patterns','name':'Patterns & Geometry','icons':['fa-shapes','fa-border-all'],'tint':['#eafaf0','#f0f1ff'],'desc':'Kaleidoscopes, tiles, grids and geometric loops.'},
 {'slug':'3d','name':'3D Backgrounds','icons':['fa-cube','fa-cubes'],'tint':['#eef0ff','#e6fbff'],'desc':'WebGL, Three.js and CSS 3D scenes.'},
 {'slug':'tunnel','name':'Tunnels','icons':['fa-hurricane','fa-circle-notch'],'tint':['#f1ebff','#ffeef6'],'desc':'Hypnotic tunnels and hyperspace travel.'},
 {'slug':'fluid','name':'Fluid Simulation','icons':['fa-droplet','fa-water'],'tint':['#e5fbff','#eaf0ff'],'desc':'Liquid, smoke and fluid-dynamics effects.'},
 {'slug':'noise','name':'Noise & Glitch','icons':['fa-tv','fa-bolt'],'tint':['#f3f3f6','#efeaff'],'desc':'Perlin noise, grain, static and glitch art.'},
 {'slug':'interactive','name':'Interactive','icons':['fa-arrow-pointer','fa-hand-pointer'],'tint':['#fff0e5','#f0f4ff'],'desc':'Backgrounds that react to your mouse or touch.'},
]
data = {'version': 2, 'categories': cats, 'backgrounds': out}
json.dump(data, open('/home/user/webapp/site/data/backgrounds.json','w'), ensure_ascii=False, separators=(',',':'))
from collections import Counter
c = Counter(t for b in out for t in b['tags'])
print(len(out), 'tagged', sum(1 for b in out if b['tags']), 'featured', len(featured), 'titled', sum('title' in b for b in out))
print(c)
