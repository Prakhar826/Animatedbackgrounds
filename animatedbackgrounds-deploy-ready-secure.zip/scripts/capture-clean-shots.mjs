#!/usr/bin/env node
/* =====================================================================
   Capture clean 640x360 preview screenshots for all backgrounds.
   - Hides CodePen embed chrome (header/footer/rerun bars)
   - Hides slider/editor UIs (dat.GUI, lil-gui, Tweakpane, range inputs)
   - Removes any DOM text element containing English words > 2 letters
     (/[A-Za-z]{3,}/) while preserving <canvas>, <svg>, and CSS backgrounds.

   Usage (requires internet access to load codepen.io embeds):
     npm install -D playwright
     npx playwright install chromium
     node scripts/capture-clean-shots.mjs          # capture all 657
     node scripts/capture-clean-shots.mjs --limit 20
     node scripts/capture-clean-shots.mjs --only AJMvQE,ALgaeV
   ===================================================================== */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SHOTS_DIR = path.join(ROOT, 'assets/shots');
const DATA_PATH = path.join(ROOT, 'data/backgrounds.json');

const args = process.argv.slice(2);
const getArg = name => {
  const i = args.indexOf(name);
  return i >= 0 ? args[i + 1] : null;
};
const limit = Number(getArg('--limit') || 0);
const only = getArg('--only') ? new Set(getArg('--only').split(',').map(s => s.trim())) : null;
const concurrency = Math.max(1, Number(getArg('--concurrency') || 4));

let playwright;
try {
  playwright = await import('playwright');
} catch (e) {
  console.error('Playwright is not installed. Run:\n  npm install -D playwright && npx playwright install chromium');
  process.exit(1);
}

const data = JSON.parse(fs.readFileSync(DATA_PATH, 'utf8'));
let list = data.backgrounds.filter(b => !b.hidden);
if (only) list = list.filter(b => only.has(b.id));
if (limit > 0) list = list.slice(0, limit);

fs.mkdirSync(SHOTS_DIR, { recursive: true });

const HIDE_EDITORS_CSS = `
  .dg.ac, .dg.main, .lil-gui, .tp-dfwv, .gui, .controls, .control-panel,
  #controls, #gui, #ui, input[type="range"], input, select, textarea, button, form {
    display: none !important;
    opacity: 0 !important;
    visibility: hidden !important;
  }
`;

const browser = await playwright.chromium.launch({ headless: true });
let done = 0, ok = 0, fail = 0;

async function captureOne(b) {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 720 }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  try {
    const url = `https://codepen.io/${b.user}/embed/${b.id}?default-tab=result&theme-id=dark&editable=false`;
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 20000 });
    await page.waitForTimeout(2200);

    // Strip CodePen embed header/footer chrome
    await page.addStyleTag({
      content: `
        #embed-header, #embed-footer, .embed-nav, .embed-footer, #rerun-button { display: none !important; }
        #output, #result-box, iframe#result { position: fixed !important; inset: 0 !important; width: 100vw !important; height: 100vh !important; }
      `
    }).catch(() => {});

    // Inside the CodePen result frame: hide slider panels AND any English text > 2 letters
    for (const frame of page.frames()) {
      if (frame === page.mainFrame()) continue;
      await frame.addStyleTag({ content: HIDE_EDITORS_CSS }).catch(() => {});
      await frame.evaluate(() => {
        const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
        const toClear = [];
        let node;
        while ((node = walker.nextNode())) {
          const parent = node.parentElement;
          if (!parent) continue;
          const tag = parent.tagName;
          if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT') continue;
          if (/[A-Za-z]{3,}/.test(node.nodeValue || '')) {
            toClear.push(node);
          }
        }
        for (const n of toClear) {
          const p = n.parentElement;
          n.nodeValue = '';
          // If parent is a pure text/UI box (no canvas/svg/img inside), hide it cleanly
          if (p && p !== document.body && !p.querySelector('canvas, svg, img, video')) {
            if (!p.textContent.trim() && p.children.length === 0) {
              p.style.setProperty('display', 'none', 'important');
            }
          }
        }
      }).catch(() => {});
    }

    await page.waitForTimeout(600);
    await page.setViewportSize({ width: 640, height: 360 });
    await page.waitForTimeout(300);
    await page.screenshot({ path: path.join(SHOTS_DIR, `${b.id}.jpg`), type: 'jpeg', quality: 86 });
    ok++;
  } catch (err) {
    fail++;
    console.warn(`! Failed ${b.id}: ${err.message.split('\n')[0]}`);
  } finally {
    done++;
    if (done % 10 === 0 || done === list.length) {
      console.log(`Progress: ${done}/${list.length} (ok=${ok}, fail=${fail})`);
    }
    await ctx.close();
  }
}

const queue = list.slice();
await Promise.all(Array.from({ length: concurrency }, async () => {
  while (queue.length) await captureOne(queue.shift());
}));

await browser.close();
console.log(`Done. Captured ${ok}/${list.length} screenshots into assets/shots/ (${fail} failed).`);
