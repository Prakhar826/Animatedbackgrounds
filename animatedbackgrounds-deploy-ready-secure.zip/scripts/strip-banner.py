#!/usr/bin/env python3
"""
Remove the CodePen security banner ("Do not enter passwords or personal
information on this page.") captured at the top of every screenshot, then
re-normalise the thumbnail to 640x360 (zoom-crop, never stretched).

The bar height differs per capture (roughly 18-160 px), so detection runs per
image, twice: once on the original, then again on the just-cropped result to
catch a trailing text line that sat below the first detection.

Signature of a banner row: centred bright glyphs on a near-black bar, with the
outer ~90 px staying dark (real artwork rarely has 4 short centred text lines).

Usage:
  python3 scripts/strip-banner.py --dry-run
  python3 scripts/strip-banner.py --montage 60
"""
import os
import glob
import json
import argparse

import numpy as np
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_W, OUT_H = 640, 360


def _rows(g):
    h, w = g.shape
    black = (g <= 26).mean(axis=1)
    mid = (g[:, 120:520] > 140).sum(axis=1)
    edge = (g[:, :90] > 140).sum(axis=1) + (g[:, w - 90:] > 140).sum(axis=1)
    text = (mid >= 8) & (black >= 0.16) & (edge <= 10)
    bar = black >= 0.52
    return text, bar


def detect_top(gray, max_passes=2):
    """Rows to drop from the top of `gray` so the banner disappears."""
    h = gray.shape[0]
    top = 0
    for _ in range(max_passes):
        sub = gray[top:]
        text, bar = _rows(sub)
        lim = min(168, sub.shape[0] - 4)
        idx = [y for y in range(lim) if text[y]]
        if not idx:
            break
        last = idx[-1]
        tail = last + 1
        while tail < lim and bar[tail]:
            tail += 1
        add = min(tail + 3, int(h * 0.30))
        if add <= 2:
            break
        top += add
    return int(min(top, int(h * 0.46)))


def cover_fit(img, top):
    if top > 0:
        img = img.crop((0, top, img.width, img.height))
    w, h = img.size
    scale = max(OUT_W / w, OUT_H / h)
    nw, nh = int(round(w * scale)), int(round(h * scale))
    img = img.resize((nw, nh), Image.LANCZOS)
    left = (nw - OUT_W) // 2
    top2 = int((nh - OUT_H) * 0.30)          # bias to keep the artwork centre
    return img.crop((left, top2, left + OUT_W, top2 + OUT_H))


def montage(images, dest, cols=10, tile=(160, 90)):
    rows = (len(images) + cols - 1) // cols
    sheet = Image.new("RGB", (tile[0] * cols, tile[1] * rows), "#101010")
    for i, im in enumerate(images):
        sheet.paste(im.resize(tile, Image.LANCZOS),
                    ((i % cols) * tile[0], (i // cols) * tile[1]))
    sheet.save(dest, quality=88)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--montage", type=int, default=0)
    ap.add_argument("--dir", default=os.path.join(ROOT, "assets", "shots"))
    args = ap.parse_args()

    files = sorted(glob.glob(os.path.join(args.dir, "*.jpg")))
    tops, outs = {}, []

    for f in files:
        gray = np.array(Image.open(f).convert("L")).astype(np.int16)
        top = detect_top(gray)
        tops[os.path.basename(f)[:-4]] = top
        if args.dry_run:
            continue
        out = cover_fit(Image.open(f).convert("RGB"), top)
        out.save(f, "JPEG", quality=87, optimize=True, progressive=True)
        outs.append(out)

    if not args.dry_run:
        with open(os.path.join(ROOT, "data", "shot-banner-heights.json"), "w") as fh:
            json.dump(tops, fh)

    vals = list(tops.values())
    hist = {}
    for v in vals:
        b = (v // 20) * 20
        hist[f"{b}-{b + 19}"] = hist.get(f"{b}-{b + 19}", 0) + 1
    print(f"images={len(files)} cropped={sum(1 for v in vals if v)}")
    print("histogram:", dict(sorted(hist.items(), key=lambda kv: int(kv[0].split('-')[0]))))

    if outs and args.montage:
        per = args.montage
        for i in range(0, len(outs), per):
            montage(outs[i:i + per], os.path.join(ROOT, "..", f"montage-{i // per + 1:02d}.jpg"))


if __name__ == "__main__":
    main()
