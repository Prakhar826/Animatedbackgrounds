/* =====================================================================
   /guide/ — "How to use an animated background in your website or app"
   Pre-rendered static page (SEO) with HowTo + FAQ structured data.
   ===================================================================== */
export default function guide({ esc, SITE, count, newsletter }) {
  const url = '/guide/';
  const title = 'How to Use an Animated Background in Your Website or App';
  const desc = 'Step-by-step guide to adding a CSS, Canvas or WebGL animated background to HTML, React, Next.js, Vue, WordPress, Webflow and mobile apps — with performance and accessibility tips.';
  const code = (lang, src) => `<pre class="code-block" data-lang="${lang}"><button class="copy-code" type="button" aria-label="Copy code"><i class="fa-regular fa-copy"></i></button><code>${esc(src.trim())}</code></pre>`;

  const sections = [
    ['pick', 'Pick a background and get the code', `
      <p>Browse the <a href="/all/">library of ${count} backgrounds</a> or open a <a href="/collection/gradient/">collection</a>. Click a card to open the live preview, then use:</p>
      <ul>
        <li><b>Get Code</b> — opens the original pen on CodePen with its HTML, CSS and JavaScript.</li>
        <li><b>Embed</b> — gives you a ready-to-paste iframe snippet.</li>
        <li><b>Fullscreen</b> — shows how the background looks at full viewport size.</li>
      </ul>
      <p>Before you ship, open the pen and check its license and any external libraries it loads (Three.js, GSAP, p5.js…). Most pens are MIT-licensed, but some authors ask for credit.</p>`],
    ['layer', 'Add it as a full-screen layer behind your content', `
      <p>The most reliable setup is a fixed layer that fills the viewport and sits behind everything else. Paste the pen's HTML inside the layer, its CSS into your stylesheet and its JavaScript before <code>&lt;/body&gt;</code>.</p>
      ${code('html', `
<body>
  <div class="animated-bg" aria-hidden="true">
    <!-- paste the pen's HTML here (canvas, svg or divs) -->
  </div>

  <main class="content">
    <h1>Your page content</h1>
  </main>

  <script src="background.js"></script>
</body>`)}
      ${code('css', `
.animated-bg {
  position: fixed;
  inset: 0;
  z-index: -1;          /* behind the page */
  overflow: hidden;
  pointer-events: none; /* clicks go to your content */
}
.animated-bg canvas,
.animated-bg svg {
  width: 100%;
  height: 100%;
  display: block;
}
.content { position: relative; }`)}
      <p>Pens often style <code>body</code> or <code>html</code> directly (for example <code>body { background: #000; overflow: hidden; }</code>). Move those rules onto <code>.animated-bg</code>, otherwise your page will stop scrolling.</p>
      <p>Want the background only inside a hero section instead of the whole page? Use <code>position: absolute</code> and give the parent section <code>position: relative; overflow: hidden;</code>.</p>`],
    ['iframe', 'Quick option: embed it with an iframe', `
      <p>If you just want to try a background, the <b>Embed</b> button gives you an iframe that loads the pen from CodePen:</p>
      ${code('html', `
<iframe
  src="https://codepen.io/USER/embed/PEN_ID?default-tab=result&theme-id=dark"
  title="Animated background"
  loading="lazy"
  style="position:fixed;inset:0;width:100%;height:100%;border:0;z-index:-1"
  aria-hidden="true" tabindex="-1"></iframe>`)}
      <p>It is fast to set up, but it depends on CodePen being online, adds their scripts to your page and can show CodePen branding. For production sites, copy the code into your own files instead.</p>`],
    ['css-only', 'CSS-only backgrounds (gradients)', `
      <p>Pure CSS backgrounds are the lightest option — no JavaScript at all. You can build one with the <a href="/create/">gradient creator</a> and copy the result:</p>
      ${code('css', `
.hero {
  background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
  background-size: 400% 400%;
  animation: gradient-move 15s ease infinite;
}
@keyframes gradient-move {
  0%, 100% { background-position: 0% 50%; }
  50%      { background-position: 100% 50%; }
}`)}`],
    ['canvas', 'Canvas and WebGL backgrounds', `
      <p>Particle, fluid and 3D backgrounds draw on a <code>&lt;canvas&gt;</code>. Three things make them behave well on a real site:</p>
      <ol>
        <li><b>Resize with the window</b> and respect <code>devicePixelRatio</code> (cap it at 2 to save battery).</li>
        <li><b>Pause when the tab is hidden</b> — <code>requestAnimationFrame</code> already does, but stop timers and audio too.</li>
        <li><b>Clean up</b> when the page or component is removed, so the loop does not keep running.</li>
      </ol>
      ${code('js', `
const canvas = document.querySelector('.animated-bg canvas');
const ctx = canvas.getContext('2d');
let raf;

function resize() {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = innerWidth * dpr;
  canvas.height = innerHeight * dpr;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}
function frame(t) {
  // ...draw one frame of the animation...
  raf = requestAnimationFrame(frame);
}
addEventListener('resize', resize);
resize();
raf = requestAnimationFrame(frame);`)}`],
    ['react', 'React and Next.js', `
      <p>Wrap the background in a component, start the animation in <code>useEffect</code> and stop it in the cleanup function. In the Next.js App Router, mark the file as a client component.</p>
      ${code('jsx', `
'use client';
import { useEffect, useRef } from 'react';

export default function AnimatedBackground() {
  const ref = useRef(null);

  useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas.getContext('2d');
    let raf;
    const resize = () => { canvas.width = innerWidth; canvas.height = innerHeight; };
    const frame = () => {
      // paste the pen's drawing code here
      raf = requestAnimationFrame(frame);
    };
    resize();
    addEventListener('resize', resize);
    raf = requestAnimationFrame(frame);
    return () => { cancelAnimationFrame(raf); removeEventListener('resize', resize); };
  }, []);

  return <canvas ref={ref} className="animated-bg" aria-hidden="true" />;
}`)}
      <p>Put the CSS from the pen into a CSS module or your global stylesheet. If the pen uses a library such as Three.js, install it from npm (<code>npm i three</code>) instead of loading it from a CDN.</p>`],
    ['vue', 'Vue and Nuxt', `
      ${code('vue', `
<template>
  <canvas ref="bg" class="animated-bg" aria-hidden="true" />
</template>

<script setup>
import { ref, onMounted, onBeforeUnmount } from 'vue';
const bg = ref(null);
let raf;

onMounted(() => {
  const ctx = bg.value.getContext('2d');
  const frame = () => { /* pen drawing code */ raf = requestAnimationFrame(frame); };
  raf = requestAnimationFrame(frame);
});
onBeforeUnmount(() => cancelAnimationFrame(raf));
</script>`)}
      <p>In Nuxt, wrap the component in <code>&lt;ClientOnly&gt;</code> because canvas code needs the browser.</p>`],
    ['builders', 'WordPress, Webflow, Wix, Shopify and Framer', `
      <ul>
        <li><b>WordPress</b> — add a <i>Custom HTML</i> block for the markup, put the CSS in <i>Appearance → Customize → Additional CSS</i>, and load the JavaScript with a code-snippets plugin or your theme's footer.</li>
        <li><b>Webflow</b> — add an <i>Embed</i> element for the HTML and paste the CSS and script into <i>Page settings → Custom code</i> (before <code>&lt;/body&gt;</code>).</li>
        <li><b>Wix</b> — use <i>Embed Code → Embed HTML</i> and paste the whole pen as one HTML document (HTML, a <code>&lt;style&gt;</code> tag and a <code>&lt;script&gt;</code> tag), then stretch the element to full width.</li>
        <li><b>Shopify</b> — create a <i>Custom Liquid</i> section, or add the code to <code>theme.liquid</code> for every page.</li>
        <li><b>Framer</b> — add an <i>Embed</i> component with the HTML, or wrap the code in a Code Component.</li>
      </ul>`],
    ['apps', 'Mobile and desktop apps', `
      <ul>
        <li><b>React Native / Expo</b> — render the pen as an HTML string in <code>react-native-webview</code>, absolutely positioned behind your views, with <code>pointerEvents="none"</code>.</li>
        <li><b>Flutter</b> — use <code>webview_flutter</code> for the live version, or rebuild simple gradients with an <code>AnimatedContainer</code>.</li>
        <li><b>Electron, Tauri and PWAs</b> — they are web pages, so the full-screen layer from step 2 works as is.</li>
        <li><b>Native iOS / Android</b> — record the background as a short looping MP4 or Lottie file and play it muted on loop. This uses far less battery than a WebView.</li>
      </ul>`],
    ['readable', 'Keep text readable on top', `
      <p>Moving, high-contrast backgrounds make text hard to read. Add a dark or light scrim between the background and your content, and check contrast against the brightest frame.</p>
      ${code('css', `
.animated-bg::after {
  content: "";
  position: absolute;
  inset: 0;
  background: rgba(10, 8, 6, .55); /* darken the animation */
}`)}`],
    ['performance', 'Performance and accessibility checklist', `
      <ul>
        <li>Respect <code>prefers-reduced-motion</code>: show a still frame or slow the animation down.</li>
        <li>Lower the particle count or resolution on small screens.</li>
        <li>Stop the animation when it is off screen with an <code>IntersectionObserver</code>.</li>
        <li>Mark the layer <code>aria-hidden="true"</code> so screen readers skip it.</li>
        <li>Test with Lighthouse — an animated background should not push your Largest Contentful Paint past 2.5 s.</li>
      </ul>
      ${code('css', `
@media (prefers-reduced-motion: reduce) {
  .animated-bg * { animation: none !important; }
}`)}
      ${code('js', `
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
if (!reduce) start();          // only animate when the user allows motion

new IntersectionObserver(([e]) => e.isIntersecting ? start() : stop())
  .observe(document.querySelector('.animated-bg'));`)}`],
    ['license', 'Credit the author', `
      <p>Every background on AnimatedBackgrounds.me was made by a CodePen author. Keep the license comment from the pen in your code, and add a credit link if the license asks for one, for example:</p>
      ${code('html', `<!-- Background: "Pen name" by Author — https://codepen.io/USER/pen/PEN_ID (MIT) -->`)}`]
  ];

  const faqs = [
    ['Are the animated backgrounds free to use?', 'They are free to browse and preview. Each background belongs to its CodePen author, and most pens are MIT-licensed, which allows commercial use with the license notice. Always check the pen before using it.'],
    ['Will an animated background slow down my website?', 'CSS-only backgrounds are very light. Canvas and WebGL backgrounds use the GPU, so cap the pixel ratio, pause them when hidden or off screen, and test with Lighthouse.'],
    ['Can I use these backgrounds in WordPress without coding?', 'Yes. Paste the HTML in a Custom HTML block, the CSS in Additional CSS and the JavaScript in a footer-code plugin. CSS-only gradients from the creator only need the CSS.'],
    ['How do I put text on top of an animated background?', 'Place the background in a fixed or absolute layer with z-index: -1 and pointer-events: none, then add a semi-transparent scrim so the text keeps enough contrast.'],
    ['Can I use an animated background in a mobile app?', 'Use a WebView in React Native or Flutter for the live version, or export a short looping video or Lottie file for native apps.']
  ];

  const ld = [
    {
      '@context': 'https://schema.org', '@type': 'HowTo', name: title, description: desc, url: SITE + url,
      totalTime: 'PT10M', tool: [{ '@type': 'HowToTool', name: 'Code editor' }],
      step: sections.map(([id, h], i) => ({ '@type': 'HowToStep', position: i + 1, name: h, url: `${SITE}${url}#${id}` }))
    },
    { '@context': 'https://schema.org', '@type': 'FAQPage', mainEntity: faqs.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })) },
    { '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: [{ '@type': 'ListItem', position: 1, name: 'Home', item: SITE + '/' }, { '@type': 'ListItem', position: 2, name: 'Guide' }] }
  ];

  const subscribe = `<form class="subscribe" data-newsletter action="${esc(newsletter.action)}" method="post">
      <div class="subscribe-copy"><h2>Get new backgrounds and guides by email</h2><p>No spam. Unsubscribe anytime.</p></div>
      <div class="subscribe-row">
        <label class="sr-only" for="nl-guide">Email address</label>
        <input id="nl-guide" type="email" name="email" required autocomplete="email" inputmode="email" placeholder="you@example.com">
        <button class="btn btn-primary" type="submit">Subscribe</button>
      </div>
      <input class="hp" type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">
      <input type="hidden" name="form_key" value="${esc(newsletter.formKey)}"><input type="hidden" name="source" value="${url}">
      <p class="subscribe-status" role="status" aria-live="polite"></p>
    </form>`;

  const body = `<nav class="breadcrumbs" aria-label="Breadcrumb"><a href="/">Home</a><i class="fa-solid fa-chevron-right"></i><span>Guide</span></nav>
  <article class="guide">
    <header class="guide-head">
      <h1>${esc(title)}</h1>
      <p class="guide-lede">Copy a background from the library into a plain HTML page, a React or Vue app, a site builder or a mobile app. Each step has code you can paste.</p>
      <div class="guide-actions"><a class="btn btn-primary" href="/all/">Browse backgrounds</a><a class="btn btn-ghost" href="/create/">Make a CSS gradient</a></div>
    </header>
    <div class="guide-layout">
      <aside class="toc" aria-label="On this page"><h4>On this page</h4><ol>${sections.map(([id, h]) => `<li><a href="#${id}">${esc(h)}</a></li>`).join('')}<li><a href="#faq">FAQ</a></li></ol></aside>
      <div class="prose">
        ${sections.map(([id, h, html], i) => `<section id="${id}" class="guide-step"><h2><span class="step-no">${i + 1}</span>${esc(h)}</h2>${html}</section>`).join('')}
        <section id="faq" class="guide-step"><h2>FAQ</h2>${faqs.map(([q, a]) => `<details class="faq"><summary>${esc(q)}</summary><p>${esc(a)}</p></details>`).join('')}</section>
      </div>
    </div>
    ${subscribe}
  </article>`;

  return { url, title, desc, body, head: ld.map(o => `<script type="application/ld+json">${JSON.stringify(o)}</script>`).join('') };
}
