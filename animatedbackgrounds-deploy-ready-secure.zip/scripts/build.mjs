#!/usr/bin/env node
/* =====================================================================
   Static site builder (zero dependencies, Node 18+)
   node scripts/build.mjs   ->   dist/
   - SPA shell pages (home, collections, background detail pages) with
     pre-rendered SEO content
   - Home hero = infinite screenshot carousel (CSS only)
   - Collection previews use unique, popular screenshots (no repeats)
   - Newsletter form (posts to the blog's subscribe endpoint)
   - Blog cards pulled from blog.animatedbackgrounds.me/rss.xml
   - Guide page, static pages, /requests/ owner queue (noindex)
   - sitemap.xml, robots.txt, manifest, service worker, legacy redirects
   ===================================================================== */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DIST = path.join(ROOT, 'dist');
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'site.config.json'), 'utf8'));
const SITE = cfg.siteUrl.replace(/\/$/, '');
const BLOG = cfg.blog.url;
const SHELL = fs.readFileSync(path.join(ROOT, 'templates/shell.html'), 'utf8');
const DOT = ['#2a9df4', '#4f7cff', '#e5484d', '#f5a524', '#6e56cf', '#d6409f', '#30a46c', '#3e63dd', '#8e4ec6', '#12a594', '#8d8d8d', '#e37926'];

/* ---------------- helpers ---------------- */
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const strip = html => String(html || '').replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
const decode = s => String(s || '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCharCode(+n)).replace(/&amp;/g, '&');
const write = (rel, content) => { const f = path.join(DIST, rel); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, content); };
const page = rel => rel.endsWith('/') ? rel + 'index.html' : rel;
const copyDir = (src, dst) => {
  if (!fs.existsSync(src)) return;
  fs.mkdirSync(dst, { recursive: true });
  for (const e of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, e.name), d = path.join(dst, e.name);
    if (e.isDirectory()) { fs.mkdirSync(d, { recursive: true }); copyDir(s, d); } else fs.copyFileSync(s, d);
  }
};

/* ---------------- clean ---------------- */
fs.rmSync(DIST, { recursive: true, force: true });
fs.mkdirSync(DIST, { recursive: true });
copyDir(path.join(ROOT, 'assets'), path.join(DIST, 'assets'));
copyDir(path.join(ROOT, 'data'), path.join(DIST, 'data'));
copyDir(path.join(ROOT, 'static'), DIST);
copyDir(path.join(ROOT, 'tools'), path.join(DIST, 'tools'));
if (!fs.existsSync(path.join(DIST, 'data/stats.json'))) write('data/stats.json', JSON.stringify({ updated: 0, b: {} }));

const VERSION = crypto.createHash('md5').update(
  ['assets/js/app.js', 'assets/js/monetize.js', 'assets/js/monetize.config.js', 'assets/css/app.css', 'assets/css/site.css', 'data/backgrounds.json', 'site.config.json']
    .map(f => fs.readFileSync(path.join(ROOT, f))).join('')
).digest('hex').slice(0, 10);

/* ---------------- data ---------------- */
const data = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/backgrounds.json'), 'utf8'));
const stats = JSON.parse(fs.readFileSync(path.join(DIST, 'data/stats.json'), 'utf8'));
const SHOTS = new Set(
  fs.existsSync(path.join(ROOT, 'assets/shots'))
    ? fs.readdirSync(path.join(ROOT, 'assets/shots')).filter(f => f.endsWith('.jpg')).map(f => f.slice(0, -4))
    : []
);
/* =====================================================================
   APPROVED REQUESTS & REMOVED BACKGROUNDS (data/approved.json)
   /requests/ exports approved.json containing both tag requests and
   removed background IDs. Commit it and the next build applies both.
   ===================================================================== */
const approvedPath = path.join(ROOT, 'data/approved.json');
let approvedData = { requests: [], removed: [] };
if (fs.existsSync(approvedPath)) {
  try { approvedData = JSON.parse(fs.readFileSync(approvedPath, 'utf8')); }
  catch (e) { console.warn('! data/approved.json could not be read:', e.message); }
}
const removedSet = new Set(Array.isArray(approvedData.removed) ? approvedData.removed : []);
const addedList = Array.isArray(approvedData.added) ? approvedData.added : [];
for (const nb of addedList) {
  if (!nb || !nb.id) continue;
  const ex = data.backgrounds.find(x => x.id === nb.id);
  if (ex) { delete ex.hidden; if (nb.title) ex.title = nb.title; if (nb.author) ex.author = nb.author; if (Array.isArray(nb.tags) && nb.tags.length) ex.tags = [...new Set([...(ex.tags || []), ...nb.tags])]; }
  else data.backgrounds.unshift({ id: nb.id, user: nb.user || 'username', title: nb.title || '', author: nb.author || '', tags: Array.isArray(nb.tags) ? nb.tags : [] });
}

const cats = data.categories.map((c, i) => ({ ...c, color: c.color || DOT[i % DOT.length], items: [] }));
const catMap = new Map(cats.map(c => [c.slug, c]));
const bgs = data.backgrounds.filter(b => !b.hidden && !removedSet.has(b.id)).map((b, i) => {
  const o = { ...b, idx: i, name: b.title || `Animated Background #${i + 1}`, by: b.author || (b.user && b.user !== 'username' ? '@' + b.user : 'CodePen creator') };
  o.tags = (b.tags || []).filter(t => catMap.has(t));
  o.tags.forEach(t => catMap.get(t).items.push(o));
  return o;
});
/** Local screenshot (never a 404): empty string when we have none yet. */
const shot = (b, _size) => SHOTS.has(b.id) ? `/assets/shots/${b.id}.jpg` : '';

let approvedCount = 0;
for (const r of (approvedData.requests || [])) {
  if (r.type !== 'tag' || !r.id || !catMap.has(r.collection)) continue;
  const b = bgs.find(x => x.id === r.id);
  const c = catMap.get(r.collection);
  if (!b || b.tags.includes(r.collection)) continue;
  b.tags.push(r.collection);
  c.items.push(b);
  approvedCount++;
}
if (removedSet.size || approvedCount || addedList.length) {
  const filteredJson = { ...data, backgrounds: data.backgrounds.filter(b => !removedSet.has(b.id)) };
  write('data/backgrounds.json', JSON.stringify(filteredJson));
}
const pen = b => `https://codepen.io/${b.user}/pen/${b.id}`;
const score = b => { const s = stats.b?.[b.id] || [0, 0]; return s[0] + s[1] * 8 + (b.featured ? 3 : 0); };

/* =====================================================================
   UNIQUE COLLECTION PREVIEWS
   Every collection gets 3 popular screenshots that are not used by any
   other collection in the "All Collections" grid, so the collage never
   repeats the same picture twice.
   ===================================================================== */
const usedPicks = new Set();
for (const c of cats) {
  // most popular first, and only screenshots we actually host locally
  const pool = c.items.filter(b => shot(b)).sort((a, b) => score(b) - score(a) || a.idx - b.idx);
  const picked = [];
  for (const b of pool) {
    if (picked.length >= 3) break;
    if (usedPicks.has(b.id)) continue;   // never repeat a screenshot in another collection
    usedPicks.add(b.id);
    picked.push(b.id);
  }
  // tiny / heavily-overlapping collections: allow a repeat so the collage is never half empty
  if (picked.length < 3) {
    for (const b of c.items) { if (picked.length >= 3) break; if (!picked.includes(b.id)) picked.push(b.id); }
  }
  c.picks = picked;
}

/* Hero reel: 3 rows of popular screenshots, all distinct. */
const heroPool = bgs.filter(b => SHOTS.has(b.id))
  .slice().sort((a, b) => score(b) - score(a) || a.idx - b.idx);
const heroSeen = new Set();
const heroPoolUnique = heroPool.filter(b => !heroSeen.has(b.id) && heroSeen.add(b.id));
const rows = [];
for (let r = 0; r < 3; r++) rows.push(heroPoolUnique.slice(r * 9, r * 9 + 9));
if (rows[2].length < 6) rows[2] = heroPoolUnique.slice(18, 27);

/* ---------------- side nav ---------------- */
const sideCats = cats.filter(c => c.items.length).map(c =>
  `<a href="/collection/${c.slug}/" data-link><span class="dot" style="background:${c.color}"></span>${esc(c.name)}<em>${c.items.length}</em></a>`).join('');

/* Client metadata: which ids have a local screenshot (so the SPA never
   requests a file that does not exist) + the unique collection picks. */
write('data/meta.json', JSON.stringify({
  updated: Date.now(),
  shots: [...SHOTS],
  picks: Object.fromEntries(cats.map(c => [c.slug, c.picks || []])),
  hero: rows.flat().map(b => b.id)
}));

/* ---------------- client config (window.AB_CONFIG) ---------------- */
const clientCfg = {
  site: SITE, blog: BLOG, apiBase: (cfg.apiBase || '').replace(/\/$/, ''),
  newsletter: cfg.newsletter, carbon: cfg.carbon, contactEmail: cfg.contactEmail, adminHash: cfg.adminHash || ''
};

/* ---------------- shell renderer ---------------- */
function render({ title, desc, url, route = 'spa', body = '', head = '', bodyAttr = '', ogType = 'website', ogImage, noindex = false }) {
  const full = title ? `${title} · ${cfg.name}` : `${cfg.name} — ${cfg.tagline}`;
  const vals = {
    TITLE: esc(full), DESC: esc(desc || cfg.description), CANONICAL: SITE + url, ROUTE: route,
    ROBOTS: noindex ? '<meta name="robots" content="noindex, follow">' : '',
    OGTYPE: ogType, OGIMAGE: esc(ogImage || SITE + '/assets/icons/android-chrome-512x512.png'),
    HEAD: head, BODYATTR: bodyAttr, COUNTALL: String(bgs.length), SIDECATS: sideCats, BLOGURL: BLOG,
    CONFIG: JSON.stringify(clientCfg).replace(/</g, '\\u003c'),
    PRERENDER: body, VERSION
  };
  return SHELL.replace(/%%([A-Z]+)%%/g, (_, k) => vals[k] ?? '');
}
const sitemap = [];
const addUrl = (loc, lastmod, priority = '0.6') => sitemap.push({ loc: SITE + loc, lastmod, priority });

/* =====================================================================
   0) LATEST BLOG POSTS (RSS from blog.animatedbackgrounds.me)
   Fetched at build time (the blog has no CORS headers). The daily
   GitHub Action rebuild keeps the home page cards fresh.
   ===================================================================== */
async function get(url) {
  const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 12000);
  try {
    const r = await fetch(url, { signal: ctl.signal, headers: { 'user-agent': 'AnimatedBackgrounds-build/3 (+https://animatedbackgrounds.me)' } });
    return r.ok ? await r.text() : '';
  } catch (e) { return ''; } finally { clearTimeout(t); }
}
const tag = (xml, name) => { const m = xml.match(new RegExp(`<${name}[^>]*>([\\s\\S]*?)<\\/${name}>`, 'i')); return m ? m[1].replace(/^<!\[CDATA\[|\]\]>$/g, '').trim() : ''; };
const attr = (xml, re) => { const m = xml.match(re); return m ? decode(m[1]) : ''; };
const absBlog = u => { try { return new URL(u, BLOG).href; } catch (e) { return ''; } };
const shortDate = d => { const t = new Date(d); return isNaN(t) ? '' : t.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric', timeZone: 'UTC' }); };

function parseRss(xml) {
  return (xml.match(/<item[\s>][\s\S]*?<\/item>/gi) || []).map(it => {
    const desc = decode(tag(it, 'description'));
    const content = decode(tag(it, 'content:encoded'));
    const image = attr(it, /<media:(?:content|thumbnail)[^>]*url="([^"]+)"/i) || attr(it, /<enclosure[^>]*url="([^"]+)"/i) || attr(desc + content, /<img[^>]*src="([^"]+)"/i);
    const text = strip(desc) || strip(content);
    const date = tag(it, 'pubDate') || tag(it, 'dc:date');
    return {
      title: strip(decode(tag(it, 'title'))), url: absBlog(strip(tag(it, 'link'))), category: strip(decode(tag(it, 'category'))),
      excerpt: text.length > 165 ? text.slice(0, 165).replace(/\s\S*$/, '') + '…' : text,
      image: image ? absBlog(image) : '', date: date ? new Date(date).toISOString() : '', dateText: shortDate(date),
      minutes: content ? Math.max(1, Math.round(strip(content).split(' ').length / 220)) : null
    };
  }).filter(p => p.title && p.url);
}
// fallback: read the cards on the blog home page (Outrank "ob-card" markup)
function parseBlogHome(html) {
  return (html.match(/<article[^>]*class="[^"]*ob-card[\s\S]*?<\/article>/gi) || []).map(a => {
    const link = a.match(/<h[23][^>]*>\s*<a[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i);
    const time = attr(a, /<time[^>]*datetime="([^"]+)"/i);
    const mins = a.match(/(\d+)\s*min read/i);
    return {
      title: link ? strip(decode(link[2])) : '', url: link ? absBlog(decode(link[1])) : '',
      category: strip(decode(attr(a, /class="ob-eyebrow"[^>]*>([^<]+)</i))),
      excerpt: strip(decode(attr(a, /class="ob-card__excerpt"[^>]*>([\s\S]*?)<\/p>/i))),
      image: absBlog(attr(a, /<img[^>]*src="([^"]+)"/i)) || '', date: time, dateText: shortDate(time), minutes: mins ? +mins[1] : null
    };
  }).filter(p => p.title && p.url);
}
let blogPosts = parseRss(await get(cfg.blog.rss));
if (!blogPosts.length) blogPosts = parseBlogHome(await get(BLOG));
if (blogPosts.length < 3) {
  const extra = parseBlogHome(await get(BLOG));
  for (const p of extra) if (!blogPosts.some(x => x.url === p.url)) blogPosts.push(p);
}
blogPosts = blogPosts.slice(0, cfg.blog.archiveCount || 12).map(p => ({ ...p, image: /^https?:/.test(p.image) && p.image !== BLOG ? p.image : '' }));
write('data/blog.json', JSON.stringify({ updated: Date.now(), posts: blogPosts }));

/* =====================================================================
   1) SHARED MARKUP PIECES (used by the prerender and mirrored in app.js)
   ===================================================================== */
const fmt = n => n == null ? '–' : n >= 1e6 ? (n / 1e6).toFixed(1).replace(/\.0$/, '') + 'M' : n >= 1e3 ? (n / 1e3).toFixed(1).replace(/\.0$/, '') + 'k' : String(n);
const viewsOf = b => (stats.b?.[b.id] || [0, 0])[0];
const likesOf = b => (stats.b?.[b.id] || [0, 0])[1];

/** Screenshot <img> with a graceful gradient fallback (never "screenshot missing"). */
function shotImg(b, { cls = '', size = 'card', alt = '' } = {}) {
  const src = shot(b);
  if (src) return `<img${cls ? ` class="${cls}"` : ''} src="${src}" alt="${esc(alt)}" loading="lazy" decoding="async" width="640" height="360">`;
  const c = (catMap.get(b.tags[0]) || {}).tint || ['#f1efec', '#e9e6e1'];
  return `<span class="shot-fallback" role="img" aria-label="${esc(alt || b.name)}" style="--fa:${c[0]};--fb:${c[1]}"><i class="fa-solid fa-wand-magic-sparkles"></i></span>`;
}
function cardHTML(b) {
  const v = viewsOf(b), n = likesOf(b), hot = v >= 500 || n >= 25;
  return `<article class="bg-card" data-id="${esc(b.id)}">
      <a class="bg-thumb" href="/background/${esc(b.id)}/" data-open="${esc(b.id)}" aria-label="Preview ${esc(b.name)}">
        ${shotImg(b, { alt: `${b.name} — animated background` })}
        <span class="play"><i class="fa-solid fa-play"></i></span>
        ${hot ? '<span class="badge"><i class="fa-solid fa-fire"></i> Hot</span>' : ''}
      </a>
      <div class="bg-info">
        <div class="bg-meta">
          <h3 title="${esc(b.name)}">${esc(b.name)}</h3>
        </div>
        <span class="stat-pill" title="Views"><i class="fa-regular fa-eye"></i> <span data-views="${esc(b.id)}">${fmt(v)}</span></span>
        <button class="like-btn" data-like="${esc(b.id)}" aria-pressed="false" aria-label="Like"><i class="fa-regular fa-heart"></i><span>${n ? fmt(n) : ''}</span></button>
        <button class="kebab" data-menu="${esc(b.id)}" aria-label="More options"><i class="fa-solid fa-ellipsis-vertical"></i></button>
      </div>
    </article>`;
}
function collectionCardHTML(c) {
  const p = (c.picks || []).map(id => bgs.find(b => b.id === id)).filter(Boolean);
  return `<article class="collection-card">
      <a href="/collection/${c.slug}/" data-link>
        <div class="cc-art n${p.length}" style="background:linear-gradient(135deg,${c.tint[0]},${c.tint[1]})">
          ${p.map(b => shotImg(b, { alt: `${c.name} background preview` })).join('')}
          <span class="cc-icon"><i class="fa-solid ${c.icons[0]}"></i></span>
        </div>
      </a>
      <div class="cc-info">
        <div><h3><a href="/collection/${c.slug}/" data-link style="color:inherit">${esc(c.name)}</a></h3><p>${c.items.length} Backgrounds</p></div>
        <button class="kebab" data-cmenu="${c.slug}" aria-label="Collection options"><i class="fa-solid fa-ellipsis-vertical"></i></button>
      </div>
    </article>`;
}
function postCardHTML(p) {
  const url = esc(p.url);
  return `<article class="post-card">
      <a class="pc-img" href="${url}">${p.image ? `<img src="${esc(p.image)}" alt="${esc(p.title)}" loading="lazy">` : '<span class="pc-ph"><i class="fa-solid fa-feather"></i></span>'}</a>
      <div class="pc-body"><span class="pc-cat">${esc(p.category || 'Blog')}</span>
        <h3><a href="${url}">${esc(p.title)}</a></h3>
        <p>${esc(p.excerpt || '')}</p>
        <div class="pc-meta"><span><i class="fa-regular fa-calendar"></i> ${esc(p.dateText || '')}</span>${p.minutes ? `<span><i class="fa-regular fa-clock"></i> ${p.minutes} min read</span>` : ''}<i class="fa-solid fa-arrow-up-right-from-square pc-ext"></i></div>
      </div></article>`;
}
const subscribeHTML = (source = '/') => `<form class="subscribe" data-newsletter action="${esc(cfg.newsletter.action)}" method="post">
      <div class="subscribe-copy"><h2><i class="fa-regular fa-envelope" style="color:var(--text-2)"></i> Get new backgrounds &amp; guides by email</h2><p>One short email when something new lands. No spam, unsubscribe anytime.</p></div>
      <div class="subscribe-row">
        <label class="sr-only" for="nl-${source.replace(/\W/g, '') || 'home'}">Email address</label>
        <input id="nl-${source.replace(/\W/g, '') || 'home'}" type="email" name="email" required autocomplete="email" inputmode="email" placeholder="you@example.com">
        <button class="btn btn-primary" type="submit"><i class="fa-solid fa-paper-plane"></i> Subscribe</button>
      </div>
      <input class="hp" type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">
      <input type="hidden" name="form_key" value="${esc(cfg.newsletter.formKey)}"><input type="hidden" name="source" value="${esc(source)}">
      <p class="subscribe-status" role="status" aria-live="polite"></p>
    </form>`;

const heroHTML = `<div class="discover-bar" id="hero-section">
        <p class="discover-count">Discover ${bgs.length} Backgrounds</p>
        <a class="announce-pill" href="/create/" data-link>
          <span class="announce-tag"><i class="fa-solid fa-wand-magic-sparkles"></i> Studio</span>
          <span>Design &amp; export custom CSS or GIF backgrounds free</span>
          <span class="announce-arrow" aria-hidden="true"><i class="fa-solid fa-arrow-right"></i></span>
        </a>
        <div class="view-toggle" role="group" aria-label="Grid layout">
          <button type="button" data-grid-mode="comfy" class="active" title="3-column gallery"><i class="fa-solid fa-table-cells-large"></i></button>
          <button type="button" data-grid-mode="compact" title="Compact grid"><i class="fa-solid fa-table-cells"></i></button>
        </div>
      </div>`;

const popularList = bgs.slice().sort((a, b) => score(b) - score(a)).slice(0, 9);
const homeBlog = blogPosts.slice(0, cfg.blog.homeCards || 3);

const homeBody = `${heroHTML}
      <section class="section" id="trending">
        <div class="bg-grid">${popularList.map(cardHTML).join('')}</div>
      </section>

      ${subscribeHTML('/')}

      <section class="section seo-intro" id="about-backgrounds">
        <h2>Free animated backgrounds, motion backgrounds &amp; GIF backgrounds</h2>
        <p>Animated Backgrounds is a hand-picked library of ${bgs.length} free <strong>animated backgrounds</strong>, <strong>motion backgrounds</strong> and <strong>moving backgrounds</strong> built with <strong>CSS animations</strong>, Canvas and WebGL. Every <strong>animation background</strong> on this page is a real, live <strong>background animation</strong> you can preview in the browser before you copy a single line of code — no signup, no paywall, no watermark.</p>
        <p>Looking for <strong>animated backgrounds CSS</strong>? Filter by the <a href="/collection/gradient/" data-link>gradients</a>, <a href="/collection/waves/" data-link>waves</a> or <a href="/collection/patterns/" data-link>patterns</a> collections — they are pure <strong>backgrounds CSS</strong> with zero JavaScript. Prefer <strong>HTML CSS backgrounds</strong> inside a page? Every detail page lists the exact <strong>html backgrounds</strong> markup. Need a still image instead of a live animation? Use the <a href="/gif/" data-link>GIF converter</a> to export any <strong>gif backgrounds</strong> loop, or grab an <strong>animated wallpaper</strong> for your desktop.</p>
        <p>New here? Start with <a href="/guide/" data-link>how to add an animated background to your site</a>, browse <a href="/popular/" data-link>the most popular background effects</a>, or open the <a href="/create/" data-link>background engine</a> and design your own <strong>background effects</strong> and <strong>animation effects</strong> from scratch.</p>
      </section>

      <section class="section" id="explore">
        <div class="section-head"><div><h2>Explore every animated background</h2><p>Scroll to load more backgrounds</p></div>
          <select class="sort-select" id="sort-select" aria-label="Sort"><option value="default" selected>Default order</option><option value="popular">Most popular</option><option value="liked">Most liked</option><option value="az">A – Z</option><option value="shuffle">Shuffle</option></select>
        </div>
        <div class="bg-grid" id="grid">${bgs.slice(0, 24).map(cardHTML).join('')}</div>
        <div class="load-more-wrap"><button class="btn btn-soft" id="load-more">Load more <i class="fa-solid fa-chevron-down"></i></button></div>
        <div class="sentinel" id="sentinel"></div>
      </section>`;

/* =====================================================================
   2) BACKGROUND APP PAGES (SPA routes, pre-rendered for SEO / no-JS)
   ===================================================================== */
const linkList = list => `<ul class="seo-list">${list.map(b => `<li><a href="/background/${b.id}/">${esc(b.name)}</a> by ${esc(b.by)}</li>`).join('')}</ul>`;
const noscript = '<noscript><p class="empty">Please enable JavaScript to preview the animated backgrounds.</p></noscript>';

write('index.html', render({ url: '/', body: homeBody + noscript }));
addUrl('/', null, '1.0');

const spaPages = [
  ['/all/', 'All Animated Backgrounds', `Browse all ${bgs.length} free animated backgrounds — CSS, Canvas and WebGL motion backgrounds you can preview live.`, '0.9'],
  ['/popular/', 'Popular Animated Backgrounds', 'The most viewed and liked animated backgrounds, moving backgrounds and background animation effects.', '0.8'],
  ['/random/', 'Random Animated Backgrounds', 'Discover random animated backgrounds and moving backgrounds — a new surprise every click.', '0.4'],
  ['/favorites/', 'My Favorites', 'Your liked animated backgrounds, saved on this device.', null],
  ['/create/', 'Background Studio — design animated backgrounds online', 'Free online animated background maker with 6 procedural effects and 8 palettes. Live preview, then export HTML, CSS or a looping GIF.', '0.8'],
  ['/gif/', 'Animated background to GIF converter — free and in-browser', 'Convert animated backgrounds into looping GIF backgrounds. Choose size, frame rate and length; everything renders in your browser.', '0.8'],
  ['/search/', 'Search', 'Search animated backgrounds.', null]
];
/* Rich, keyword-bearing prerendered copy for the tool pages so they rank
   on their own and read properly with JavaScript disabled. */
const toolBody = {
  '/create/': `
    <h1>Background Studio — design animated backgrounds online</h1>
    <p>The Background Studio is a free <strong>animated background maker</strong> that runs entirely in your browser. Pick one of six procedural <strong>background effects</strong> — aurora, waves, particles, plasma, tunnel or mesh — choose a palette, then tune speed, density, scale, glow and grain until the <strong>background animation</strong> feels right.</p>
    <p>Everything you see is a live canvas render, so the preview is the real thing: no watermarks, no signup, no upload. When you are happy, export a self-contained HTML file, copy the matching <strong>backgrounds CSS</strong>, or render the animation into a looping <strong>GIF background</strong>.</p>
    <h2>Six effects, eight palettes, endless combinations</h2>
    <ul>
      <li><b>Aurora</b> — soft colour orbs that drift like a northern-lights <strong>animated wallpaper</strong>.</li>
      <li><b>Waves</b> — layered sine bands, the classic <strong>motion background</strong> for hero sections.</li>
      <li><b>Particles</b> — glowing dust that floats and twinkles.</li>
      <li><b>Plasma</b> — fluid colour fields with a retro shader feel.</li>
      <li><b>Tunnel</b> — hypnotic rings for intros and 404 pages.</li>
      <li><b>Mesh</b> — bold diagonal gradients for posters and headers.</li>
    </ul>
    <p>Made something you love? Press <b>Submit to the library</b> and it goes into the review queue — the best creations are featured in the collections.</p>
    <p>Prefer to browse instead of build? Start from <a href="/collection/gradient/" data-link>animated gradients</a>, <a href="/collection/waves/" data-link>wave animations</a> or <a href="/popular/" data-link>the most popular backgrounds</a>.</p>${noscript}`,
  '/gif/': `
    <h1>Animated background to GIF converter</h1>
    <p>Convert any animated background into a looping <strong>GIF background</strong> right here in your browser. Choose an effect and palette, set the output size, frame rate and length, then press convert — every frame is drawn on a canvas and encoded into a single GIF.</p>
    <p>Nothing is uploaded: the converter uses your device's own CPU, so there is no file-size limit and your artwork stays private. Typical results are 480 × 270 at 15 fps with 128 colours, which keeps <strong>gif backgrounds</strong> well under a megabyte and safe to paste into slides, docs, READMEs or chat.</p>
    <h2>When should you use a GIF instead of CSS?</h2>
    <p>A GIF is perfect for places where CSS cannot run — presentation decks, Figma frames, Notion pages, GitHub READMEs, email signatures and social posts. For a live website a <a href="/collection/gradient/" data-link>CSS animated background</a> is always sharper and dramatically lighter, so use the converter for still destinations and live CSS for the web.</p>
    <h2>How the conversion works</h2>
    <ol>
      <li>Pick an effect, palette and motion settings (or press <b>Random look</b>).</li>
      <li>Choose size, frame rate and clip length.</li>
      <li>Press <b>Convert to GIF</b> and watch the progress bar.</li>
      <li>Download the finished <strong>animated GIF</strong> — it loops seamlessly.</li>
    </ol>
    <p>Want a different animation first? Open the <a href="/create/" data-link>Background Studio</a> and design one from scratch.</p>${noscript}`
};
for (const [url, title, desc, prio] of spaPages) {
  const list = url === '/all/' ? bgs : url === '/popular/' ? bgs.slice().sort((a, b) => score(b) - score(a)).slice(0, 60) : [];
  const body = toolBody[url]
    ? toolBody[url]
    : url === '/favorites/'
      ? `<h1>${esc(title)}</h1><p>${esc(desc)}</p>${noscript}`
      : `<h1>${esc(title)}</h1><p>${esc(desc)}</p>${list.length ? linkList(list) : ''}${noscript}`;
  write(page(url), render({ url, title, desc, noindex: !prio, body }));
  if (prio) addUrl(url, null, prio);
}
/** Per-collection SEO copy. Each entry adds real, non-duplicated prose that
    targets the keyword variants people actually search for, plus an FAQ
    block that is also emitted as FAQPage structured data. */
const catSEO = {
  waves: {
    kw: 'wave animation backgrounds, CSS wave backgrounds, ocean motion backgrounds',
    intro: [
      'Wave animations are the most versatile <strong>moving backgrounds</strong> on the web: they read as calm, premium and technical all at once, and because they are built from sine curves they loop perfectly forever.',
      'Every wave here is a pure CSS or Canvas <strong>background animation</strong> — no video files, no plugins. Drop one behind a hero section, a pricing table or a full-screen landing page and it keeps adapting to any viewport size.'
    ],
    faq: [
      ['How do I add a wave background to my site?', 'Open any background, press <b>Embed</b> to copy an iframe, or <b>Get Code</b> to copy the CSS and HTML into your own stylesheet. The <a href="/guide/">step-by-step guide</a> covers both routes.'],
      ['Are these wave backgrounds free?', 'Yes. Every background links to its original CodePen, and most are MIT or free-to-use. Check the individual pen licence before commercial use.'],
      ['Can I use a wave background in a dark theme?', 'Most of the collection is dark-by-default, and the light ones pair well with a translucent overlay. Try adding <code>filter: brightness(.85)</code> behind your content.']
    ]
  },
  bubbles: {
    kw: 'bubble backgrounds, blob backgrounds, bokeh backgrounds',
    intro: [
      'Bubbles, blobs and bokeh make an <strong>animation background</strong> feel soft and friendly — ideal for product pages, onboarding screens and anything aimed at consumers.',
      'Morphing blobs are pure CSS <code>border-radius</code> animation, which means they cost almost nothing to render even on older phones.'
    ],
    faq: [
      ['What is a blob background?', 'A blob is an organic shape animated by shifting its CSS border-radius over time. It reads as a soft floating object rather than a geometric box.'],
      ['Do bubble backgrounds hurt performance?', 'Pure CSS ones do not — they animate on the compositor. Canvas versions use the GPU. Avoid stacking more than one animated layer per page.']
    ]
  },
  hearts: {
    kw: 'heart backgrounds, valentine backgrounds, love animation backgrounds',
    intro: [
      'Floating hearts are a seasonal favourite for Valentine campaigns, wedding invitations and greeting pages — a warm <strong>background effect</strong> that instantly sets a tone.',
      'The collection mixes CSS-only heart particles with Canvas systems so you can pick the weight that matches your page.'
    ],
    faq: [
      ['Are these heart backgrounds suitable for Valentine\u2019s Day pages?', 'Yes — they were collected for exactly that. Pair a soft heart loop with a serif headline for a classic card look.'],
      ['Can I change the heart colour?', 'Most CSS versions expose a single colour variable. Open the pen, change one hex value and every heart updates.']
    ]
  },
  particles: {
    kw: 'particle backgrounds, particle animation, snow and glitter backgrounds',
    intro: [
      'Particle systems give you depth without an image: dust, snow, glitter, fireflies or connected dots drifting across a dark field — a timeless <strong>motion background</strong>.',
      'The Canvas implementations here use a single rAF loop and a fixed particle budget, so they stay smooth on laptops and phones alike.'
    ],
    faq: [
      ['How many particles should I use?', 'Between 60 and 120 on a typical hero section. Above roughly 250 the effect stops looking better and starts costing frames.'],
      ['Can I make a snow background?', 'Yes — the winter entries in this collection are snow systems with adjustable drift and fall speed.']
    ]
  },
  space: {
    kw: 'space backgrounds, starfield backgrounds, galaxy backgrounds',
    intro: [
      'Starfields and galaxies are the classic <strong>3D background</strong> trick: a few thousand points moving toward the camera is enough to feel like deep space.',
      'All entries are lightweight — either a CSS star layer or a Canvas warp field — with no texture downloads.'
    ],
    faq: [
      ['What is a starfield background?', 'A starfield projects points in 3D space toward the viewer so they accelerate outward from a vanishing point, producing a warp-speed feel.'],
      ['Can I add a planet or nebula?', 'Several entries layer a radial-gradient nebula under the stars. Swap the gradient colours to match your brand.']
    ]
  },
  gradient: {
    kw: 'animated gradient backgrounds, CSS gradient animation, gradient backgrounds css',
    intro: [
      'Animated gradients are the workhorse of modern web design — a full-bleed <strong>backgrounds CSS</strong> effect with no assets at all, so it loads instantly everywhere.',
      'Almost everything here is pure <strong>css animations</strong>: a linear or radial gradient with a shifting <code>background-position</code>. That means you can copy three lines of CSS and own it.'
    ],
    faq: [
      ['How do I make an animated gradient in CSS?', 'Set a linear-gradient with <code>background-size: 400% 400%</code>, then animate <code>background-position</code> from <code>0% 50%</code> to <code>100% 50%</code> and back. The <a href="/create/">Background Studio</a> writes that CSS for you.'],
      ['Which gradient is best for a hero section?', 'A two- or three-stop gradient at a low contrast ratio keeps text readable. Add a dark veil if your body copy sits on top.'],
      ['Can I generate my own?', 'Yes — use the <a href="/create/">Background Studio</a> to pick colours and speed, then copy the finished CSS.']
    ]
  },
  patterns: {
    kw: 'pattern backgrounds, geometric backgrounds, kaleidoscope backgrounds',
    intro: [
      'Geometric patterns and kaleidoscopes turn a flat page into something with texture — a <strong>background effect</strong> that reads as considered rather than decorative.',
      'Many entries are single-element CSS tricks: repeating gradients, conic gradients and rotating masks that tile forever.'
    ],
    faq: [
      ['How do I make a repeating CSS pattern?', 'Use <code>repeating-linear-gradient</code> or <code>repeating-conic-gradient</code> on a pseudo-element, then animate <code>background-position</code> for motion.'],
      ['Will patterns make text hard to read?', 'Use a low-contrast pattern and put a solid or blurred panel behind the text. Every card page shows the intended composition.']
    ]
  },
  '3d': {
    kw: '3d backgrounds, WebGL backgrounds, three.js backgrounds',
    intro: [
      'WebGL and CSS 3D scenes bring real depth to a landing page — a genuine <strong>background animation</strong> rather than a looping image.',
      'These are the heaviest backgrounds on the site, so they are all lazy-loaded and only mount when you open the preview.'
    ],
    faq: [
      ['Are WebGL backgrounds safe on mobile?', 'Yes, but cap the pixel ratio at 1.5 and pause rendering when the tab is hidden. The pens here already do both.'],
      ['Which library do these use?', 'Most use Three.js or raw WebGL; a few are pure CSS 3D with <code>transform-style: preserve-3d</code>.']
    ]
  },
  tunnel: {
    kw: 'tunnel backgrounds, hyperspace backgrounds, zoom animation backgrounds',
    intro: [
      'Tunnel and hyperspace effects pull the eye to the centre of the screen — perfect for intros, 404 pages and product reveals.',
      'Every tunnel here is a loop of expanding shapes, which means it can run for minutes without a visible seam.'
    ],
    faq: [
      ['What makes a tunnel loop seamlessly?', 'Each ring\u2019s progress is taken modulo one, so rings recycle from the centre the instant the outermost one leaves the frame.'],
      ['Can a tunnel background be used behind text?', 'Yes, with a radial veil toward the centre — the collection includes several with a built-in vignette.']
    ]
  },
  fluid: {
    kw: 'fluid backgrounds, liquid backgrounds, smoke animation backgrounds',
    intro: [
      'Liquid, smoke and fluid-dynamics effects are the most organic <strong>background effects</strong> on the site — they feel alive because no two frames are identical.',
      'Most are shader- or Canvas-based and use a low-resolution buffer upscaled with smoothing, which keeps them fast despite the heavy maths.'
    ],
    faq: [
      ['What is a fluid simulation background?', 'A velocity field is advected and diffused each frame, so colour is carried around the canvas like ink in water.'],
      ['Are these GPU heavy?', 'Yes — they are the most demanding family here. Use them on desktop hero sections rather than long pages.']
    ]
  },
  noise: {
    kw: 'noise backgrounds, grain backgrounds, glitch animation backgrounds',
    intro: [
      'Noise, grain and glitch give a page a filmic or cyberpunk edge — an <strong>animation effect</strong> that adds texture without competing with content.',
      'The grain overlays here are tiny tiled PNG or generated ImageData patterns, so the cost is a single repeated fill.'
    ],
    faq: [
      ['How do I add film grain in CSS?', 'Overlay a tiled noise image (or an SVG turbulence filter) with <code>mix-blend-mode: overlay</code> and a low opacity — around 0.05 to 0.12.'],
      ['Will glitch effects hurt accessibility?', 'Fast flashing can be a problem. Keep the cycle slow and respect <code>prefers-reduced-motion</code>.']
    ]
  },
  interactive: {
    kw: 'interactive backgrounds, mouse follower backgrounds, cursor reaction backgrounds',
    intro: [
      'Interactive backgrounds react to the pointer, the scroll position or the device tilt — the most engaging <strong>moving backgrounds</strong> you can put on a portfolio or agency site.',
      'They are all built with a single pointer listener and a throttled rAF loop, so the cost stays predictable.'
    ],
    faq: [
      ['Do interactive backgrounds work on touch?', 'Yes — the pens fall back to touch coordinates and simply idle when there is no input.'],
      ['Should I use one behind a form?', 'Be careful: movement near inputs distracts. Use a subtle version, or pause the animation while an input has focus.']
    ]
  }
};

const catLd = c => {
  const seo = catSEO[c.slug] || {};
  const url = `${SITE}/collection/${c.slug}/`;
  const graph = [{
    '@context': 'https://schema.org', '@type': 'CollectionPage',
    name: `${c.name} — free animated backgrounds`, url,
    description: `${c.items.length} free ${c.name.toLowerCase()} animated backgrounds. ${c.desc}`,
    isPartOf: { '@type': 'WebSite', name: 'Animated Backgrounds', url: SITE + '/' },
    mainEntity: {
      '@type': 'ItemList', numberOfItems: c.items.length,
      itemListElement: c.items.slice(0, 24).map((b, i) => ({
        '@type': 'ListItem', position: i + 1, name: b.name, url: `${SITE}/background/${b.id}/`
      }))
    }
  }, {
    '@context': 'https://schema.org', '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Home', item: SITE + '/' },
      { '@type': 'ListItem', position: 2, name: 'Collections', item: SITE + '/all/' },
      { '@type': 'ListItem', position: 3, name: c.name, item: url }
    ]
  }];
  if (seo.faq && seo.faq.length) graph.push({
    '@context': 'https://schema.org', '@type': 'FAQPage',
    mainEntity: seo.faq.map(([q, a]) => ({
      '@type': 'Question', name: q,
      acceptedAnswer: { '@type': 'Answer', text: String(a).replace(/<[^>]+>/g, '') }
    }))
  });
  return graph;
};

for (const c of cats) {
  const url = `/collection/${c.slug}/`;
  const og = (c.picks || []).map(id => bgs.find(b => b.id === id)).find(b => shot(b));
  const seo = catSEO[c.slug] || { kw: '', intro: [], faq: [] };
  const catWord = c.name.replace(/\s*(Animations|Backgrounds)$/i, '').toLowerCase();
  const desc = `${c.items.length} free ${catWord} animated backgrounds — ${seo.kw || c.desc}. Preview each motion background live and copy the CSS.`;
  const faqHTML = seo.faq && seo.faq.length ? `<section class="section faq" id="faq">
      <h2>${esc(c.name)} — frequently asked questions</h2>
      ${seo.faq.map(([q, a]) => `<details><summary>${q}</summary><p>${a}</p></details>`).join('')}
    </section>` : '';
  const introHTML = (seo.intro || []).map(p => `<p>${p}</p>`).join('');
  write(page(url), render({
    url,
    title: `${c.name} — ${c.items.length} free animated ${catWord} backgrounds`,
    desc,
    ogImage: og ? SITE + shot(og) : undefined,
    ogType: 'website',
    head: `<script type="application/ld+json">${JSON.stringify(catLd(c))}</script>`,
    body: `<h1>${esc(c.name)} — free animated backgrounds</h1>
      <div class="seo-intro"><p>${esc(c.desc)} ${esc(seo.kw ? 'Popular searches: ' + seo.kw + '.' : '')}</p>${introHTML}</div>
      <div class="bg-grid">${c.items.slice().sort((a, b) => score(b) - score(a)).slice(0, 12).map(cardHTML).join('')}</div>
      <h2>Every background in ${esc(c.name)}</h2>
      ${linkList(c.items)}${faqHTML}
      <p class="muted">Looking for something else? Browse <a href="/all/" data-link>all ${bgs.length} animated backgrounds</a>, the <a href="/popular/" data-link>most popular moving backgrounds</a>, or build your own in the <a href="/create/" data-link>Background Studio</a>.</p>${noscript}`
  }));
  if (c.items.length) addUrl(url, null, '0.85');
}
for (const b of bgs) {
  const url = `/background/${b.id}/`;
  const cat = b.tags[0] && catMap.get(b.tags[0]);
  const ld = { '@context': 'https://schema.org', '@type': 'CreativeWork', name: b.name, author: { '@type': 'Person', name: b.by }, url: SITE + url, isBasedOn: pen(b) };
  if (shot(b)) ld.image = SITE + shot(b);
  write(page(url), render({
    url, title: b.name, desc: `${b.name} by ${b.by} — free animated background${cat ? ' in ' + cat.name : ''}. Preview live, like it and get the HTML/CSS/JS code.`,
    ogImage: shot(b) ? SITE + shot(b) : undefined, head: `<script type="application/ld+json">${JSON.stringify(ld)}</script>`,
    body: `<h1>${esc(b.name)}</h1><p>by ${esc(b.by)}${cat ? ` · <a href="/collection/${cat.slug}/">${esc(cat.name)}</a>` : ''}</p>
      ${shot(b) ? `<img src="${shot(b)}" alt="${esc(b.name)}" width="640" height="360" loading="lazy">` : ''}
      <p><a href="${pen(b)}" rel="noopener">Get the code on CodePen</a> · <a href="/guide/">How to add it to your site</a></p>${noscript}`
  }));
  addUrl(url, null, b.featured ? '0.6' : '0.5');
}
// SPA fallback for unknown URLs. The shell redirects any /blog/* path to the blog.
write('404.html', render({ url: '/404', title: 'Page not found', noindex: true, body: '' }));

/* =====================================================================
   3) GUIDE  (how to use a background in a website or app)
   ===================================================================== */
const guide = (await import('./guide.mjs')).default({ esc, SITE, count: bgs.length, newsletter: cfg.newsletter });
write(page(guide.url), render({ url: guide.url, route: 'page', title: guide.title, desc: guide.desc, ogType: 'article', head: guide.head, body: guide.body }));
addUrl(guide.url, new Date().toISOString().slice(0, 10), '0.9');

/* =====================================================================
   4) STATIC PAGES
   ===================================================================== */
const staticPages = {
  '/about/': ['About', 'About AnimatedBackgrounds.me and its creator.', `<h1>About Animated Backgrounds</h1>
    <p>AnimatedBackgrounds.me is a free, hand-picked library of ${bgs.length} animated backgrounds built with CSS, Canvas and WebGL. Every background links to its original CodePen so you can study, remix and use the code (please respect each author's license).</p>
    <h2>Who is behind it?</h2>
    <p>Hi, I'm <b>Prakhar Tripathi</b>, a self-taught front-end developer, UI designer and tech enthusiast from India. I began my programming journey in July 2019 with zero knowledge of code, and I have always loved creating my own designs and tools with HTML and CSS.</p>
    <p>Besides building websites I enjoy blogging and sharing what I learn — read the <a href="${BLOG}">blog</a> or the <a href="/guide/">guide to using animated backgrounds</a>.</p>
    <h2>Contact</h2><p>Questions, takedown requests or partnership ideas? Email <a href="mailto:${cfg.contactEmail}">${cfg.contactEmail}</a>.</p>`],
  '/contact/': ['Contact', 'Contact AnimatedBackgrounds.me.', `<h1>Contact</h1>
    <p>Email: <a href="mailto:${cfg.contactEmail}">${cfg.contactEmail}</a></p>
    <p>Want to suggest a background? Use the <b>+</b> button at the top of the page to submit a CodePen link. To suggest a collection for an existing background, open its preview and click <b>Add tag</b>.</p>
    <p>If you are the author of a background listed here and want it credited differently or removed, email us and we will update it within 48 hours.</p>`],
  '/privacy-policy/': ['Privacy Policy', 'Privacy policy for AnimatedBackgrounds.me.', `<h1>Privacy Policy</h1><p><i>Last updated: ${new Date().toISOString().slice(0, 10)}</i></p>
    <h2>Data stored on your device</h2><p>Your likes/favorites, theme, grid preference and creations are stored only in your browser's <code>localStorage</code>. We have no user accounts and never receive this data. You can export or delete it in Settings at any time.</p>
    <h2>View &amp; like counters</h2><p>To show how many times a background was viewed or liked we send an anonymous counter request (no cookies, no personal data) to a public counter service (Abacus). Only an aggregate number is stored.</p>
    <h2>Collection requests and submissions</h2><p>When you suggest a collection for a background or submit a CodePen link, we store the background ID, the collection and the optional name or note you enter. Requests are reviewed by hand before anything changes on the site.</p>
    <h2>Newsletter</h2><p>If you subscribe, your email address is sent to our blog platform (blog.animatedbackgrounds.me) and used only to send new articles. Every email has an unsubscribe link.</p>
    <h2>Analytics &amp; advertising</h2><p>We use Google Analytics to understand traffic, and Google AdSense and Carbon Ads to show ads. These services may use cookies; see <a href="https://policies.google.com/technologies/partner-sites" rel="noopener" target="_blank">how Google uses data</a> and <a href="https://www.carbonads.net/privacy" rel="noopener" target="_blank">Carbon's privacy policy</a>.</p>
    <h2>Optional idle-compute sharing</h2><p>If (and only if) you opt in, the site may use a small amount of your device's idle computing power to process AI tasks through a partner network (e.g. ZeroGPU) while the tab is open and your device is idle, charging or well charged. No personal data is collected and you can switch it off in Settings.</p>
    <h2>Embedded content</h2><p>Live previews are embedded from CodePen, which is subject to CodePen's own privacy policy.</p>
    <h2>Contact</h2><p><a href="mailto:${cfg.contactEmail}">${cfg.contactEmail}</a></p>`]
};
for (const [url, [title, desc, html]] of Object.entries(staticPages)) {
  write(page(url), render({ url, route: 'page', title, desc, body: `<article class="page prose">${html}</article>` }));
  addUrl(url, null, '0.3');
}

/* ---------- /requests/ (owner-only review queue; never in sitemap/robots) ---------- */
write('requests/index.html', render({
  url: '/requests/', route: 'admin', title: 'Requests', noindex: true,
  head: '<meta name="robots" content="noindex, nofollow">',
  body: `<section class="section admin" id="admin"><noscript><p class="empty">JavaScript is required.</p></noscript></section>`
}));

/* =====================================================================
   5) REDIRECTS (old animatedbackgrounds.me URLs + the removed /blog)
   ===================================================================== */
function redirectPage(to) {
  const abs = /^https?:/.test(to) ? to : SITE + to;
  return `<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Redirecting…</title><link rel="canonical" href="${abs}"><meta name="robots" content="noindex"><meta http-equiv="refresh" content="0; url=${to}"><script>location.replace(${JSON.stringify(to)}${/^https?:/.test(to) ? '' : '+location.search+location.hash'})</script></head><body><p>This page has moved to <a href="${to}">${abs}</a>.</p></body></html>`;
}
const legacy = {
  'wave.html': '/collection/waves/', 'Bubble.html': '/collection/bubbles/', 'heart.html': '/collection/hearts/',
  'pattern.html': '/collection/patterns/', '3d.html': '/collection/3d/', 'Tunnel.html': '/collection/tunnel/',
  'fluid.html': '/collection/fluid/', 'Noise.html': '/collection/noise/', 'gradients.html': '/collection/gradient/',
  'hover.html': '/collection/interactive/', 'Rabba.html': '/', 'about.html': '/about/', 'Submit/index.html': '/',
  // the blog lives on its own subdomain now
  'blog/index.html': BLOG, 'blog.html': BLOG,
  'blog/rss.xml': BLOG + 'rss.xml'
};
for (const [from, to] of Object.entries(legacy)) write(from, redirectPage(to));
// old post URLs (/blog/<slug>/, /blog/<slug>.html) -> blog home
write('blog/post/index.html', redirectPage(BLOG));

/* =====================================================================
   6) PWA: manifest, service worker, offline page
   ===================================================================== */
write('manifest.webmanifest', JSON.stringify({
  id: '/', name: cfg.name, short_name: 'Animated BG', description: cfg.description,
  start_url: '/?source=pwa', scope: '/', display: 'standalone', display_override: ['window-controls-overlay', 'standalone'],
  orientation: 'any', background_color: '#0f0f10', theme_color: '#0f0f10', categories: ['design', 'developer', 'productivity'],
  icons: [
    { src: '/assets/icons/android-chrome-192x192.png', sizes: '192x192', type: 'image/png', purpose: 'any' },
    { src: '/assets/icons/android-chrome-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'any' },
    { src: '/assets/icons/android-chrome-512x512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' }
  ],
  shortcuts: [
    { name: 'Popular', url: '/popular/', icons: [{ src: '/assets/icons/android-chrome-192x192.png', sizes: '192x192' }] },
    { name: 'Favorites', url: '/favorites/', icons: [{ src: '/assets/icons/android-chrome-192x192.png', sizes: '192x192' }] },
    { name: 'Create', url: '/create/', icons: [{ src: '/assets/icons/android-chrome-192x192.png', sizes: '192x192' }] }
  ]
}, null, 2));
write('offline.html', render({ url: '/offline.html', route: 'page', title: 'Offline', noindex: true, body: `<div class="empty"><i class="fa-solid fa-wifi big"></i><h3>You are offline</h3><p>Pages you've visited before still work. Live previews need a connection.</p><a class="btn btn-primary" href="/">Try again</a></div>` }));
write('sw.js', fs.readFileSync(path.join(ROOT, 'templates/sw.js'), 'utf8').replace('__VERSION__', VERSION));

/* =====================================================================
   7) sitemap / robots / misc
   ===================================================================== */
write('sitemap.xml', `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${sitemap.map(u => `<url><loc>${u.loc}</loc>${u.lastmod ? `<lastmod>${u.lastmod}</lastmod>` : ''}<priority>${u.priority}</priority></url>`).join('\n')}\n</urlset>\n`);
write('robots.txt', `User-agent: *\nAllow: /\nDisallow: /tools/\nDisallow: /search/\nDisallow: /requests/\n\nSitemap: ${SITE}/sitemap.xml\n`);
write('.nojekyll', '');

console.log(`✔ Built ${bgs.length} backgrounds, ${cats.length} collections, ${blogPosts.length} blog posts, ${SHOTS.size} local screenshots, ${sitemap.length} sitemap URLs → dist/ (v${VERSION})`);
