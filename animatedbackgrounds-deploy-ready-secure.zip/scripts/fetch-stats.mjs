#!/usr/bin/env node
/* =====================================================================
   Pull global view/like counters from the free Abacus counter API into
   data/stats.json (used for "Popular" sorting & instant counts).
   Runs daily in GitHub Actions. Respects the 30 req / 10 s rate limit.
   Usage: node scripts/fetch-stats.mjs
   ===================================================================== */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const NS = 'animatedbackgrounds.me';
const API = 'https://abacus.jasoncameron.dev';
const OUT = path.join(ROOT, 'data/stats.json');

// MUST match ckey() in assets/js/app.js
function djb2(s) { let h = 5381; for (let i = 0; i < s.length; i++) h = ((h * 33) ^ s.charCodeAt(i)) >>> 0; return h.toString(36); }
function ckey(prefix, id) { let k = (prefix + '-' + id).replace(/[^A-Za-z0-9_.-]/g, '-'); return k.length <= 64 ? k : k.slice(0, 54) + '-' + djb2(k); }
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function get(key, tries = 4) {
  for (let i = 0; i < tries; i++) {
    try {
      const r = await fetch(`${API}/get/${NS}/${key}`);
      if (r.status === 404) return 0;
      if (r.status === 429) { await sleep(Number(r.headers.get('retry-after')) || 3000); continue; }
      if (!r.ok) { await sleep(1000); continue; }
      const j = await r.json(); return typeof j.value === 'number' ? j.value : 0;
    } catch (e) { await sleep(1500); }
  }
  return null; // unknown -> keep previous value
}

const data = JSON.parse(fs.readFileSync(path.join(ROOT, 'data/backgrounds.json'), 'utf8'));
const prev = fs.existsSync(OUT) ? JSON.parse(fs.readFileSync(OUT, 'utf8')) : { b: {} };

const jobs = [];
for (const b of data.backgrounds) { jobs.push(['b', b.id, 0, ckey('v', b.id)]); jobs.push(['b', b.id, 1, ckey('l', b.id)]); }

const out = { updated: Date.now(), b: {} };
let done = 0;
const BATCH = 25; // < 30 per 10 s
for (let i = 0; i < jobs.length; i += BATCH) {
  const t0 = Date.now();
  await Promise.all(jobs.slice(i, i + BATCH).map(async ([kind, id, idx, key]) => {
    let v = await get(key);
    if (kind === 'b') {
      const old = prev.b?.[id] || [0, 0];
      if (v == null) v = old[idx];
      out.b[id] = out.b[id] || [0, 0]; out.b[id][idx] = v;
    }
    done++;
  }));
  process.stdout.write(`\r${done}/${jobs.length}`);
  const wait = 10500 - (Date.now() - t0); if (wait > 0 && i + BATCH < jobs.length) await sleep(wait);
}
// drop zero entries to keep the file small
for (const [k, v] of Object.entries(out.b)) if (!v[0] && !v[1]) delete out.b[k];
fs.writeFileSync(OUT, JSON.stringify(out));
console.log(`\n✔ stats.json: ${Object.keys(out.b).length} backgrounds with activity`);
