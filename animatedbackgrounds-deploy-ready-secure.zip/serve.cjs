const http=require('http'),fs=require('fs'),path=require('path');
const ROOT=path.join(__dirname,'dist');
const TYPES={'.html':'text/html;charset=utf-8','.css':'text/css','.js':'application/javascript','.json':'application/json','.jpg':'image/jpeg','.png':'image/png','.svg':'image/svg+xml','.xml':'application/xml','.txt':'text/plain','.webmanifest':'application/manifest+json','.ico':'image/x-icon'};
http.createServer((req,res)=>{
  let p=decodeURIComponent(req.url.split('?')[0]);
  let f=path.join(ROOT,p);
  try{ if(fs.statSync(f).isDirectory()) f=path.join(f,'index.html'); }catch(e){}
  if(!fs.existsSync(f)){ const alt=path.join(ROOT,(p.replace(/\/$/,'')||'/')+'.html'); if(fs.existsSync(alt)) f=alt; }
  if(!fs.existsSync(f)) f=path.join(ROOT,'404.html');
  fs.readFile(f,(e,b)=>{ if(e){res.writeHead(500);return res.end('err');}
    res.writeHead(200,{'Content-Type':TYPES[path.extname(f)]||'application/octet-stream','Cache-Control':'public,max-age=600'});
    res.end(b); });
}).listen(3000,'0.0.0.0',()=>console.log('up on 3000'));
